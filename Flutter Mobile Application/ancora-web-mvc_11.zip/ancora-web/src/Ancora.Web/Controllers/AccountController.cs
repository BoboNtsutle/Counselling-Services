using System.Security.Claims;
using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services;
using Ancora.Web.Services.Supabase;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Controllers;

/// <summary>
/// MODULE 1 — Login / logout / forgot password (FR-01).
/// Uses the SAME Supabase accounts as the Flutter app.
/// Only admins and psychologists may use the web app.
/// </summary>
[AllowAnonymous]
public class AccountController : Controller
{
    private readonly SupabaseAuthService _auth;
    private readonly SupabaseSessionStore _session;
    private readonly ProfileService _profiles;
    private readonly SupabaseClient _db;
    private readonly ILogger<AccountController> _logger;

    public AccountController(SupabaseAuthService auth, SupabaseSessionStore session, ProfileService profiles, SupabaseClient db, ILogger<AccountController> logger)
    {
        _auth = auth;
        _session = session;
        _profiles = profiles;
        _db = db;
        _logger = logger;
    }

    [HttpGet]
    [AllowAnonymous]
    public IActionResult Register() => View(new Models.ViewModels.RegisterViewModel());

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(Models.ViewModels.RegisterViewModel model)
    {
        // The role the person asks for. They stay a student until an admin approves a staff request.
        var requested = (model.RequestedRole ?? "").Trim().ToLower() switch
        {
            "psychologist" => Roles.Psychologist,
            "admin" => Roles.Admin,
            _ => Roles.Student
        };

        // Only students have a student number. Staff are not asked for one.
        if (requested == Roles.Student)
        {
            if (string.IsNullOrWhiteSpace(model.StudentNumber))
                ModelState.AddModelError(nameof(model.StudentNumber), "Please enter your student number.");
        }
        else
        {
            model.StudentNumber = "";
            ModelState.Remove(nameof(model.StudentNumber));
        }

        if (!ModelState.IsValid) return View(model);

        try
        {

            // 1) Create the Supabase account. The details travel with it, so the profile can still be
            //    built at first sign-in if Supabase wants the email confirmed first.
            var session = await _auth.SignUpAsync(model.Email, model.Password, new
            {
                display_name = model.DisplayName.Trim(),
                requested_role = requested,
                student_number = (model.StudentNumber ?? "").Trim(),
                phone_number = (model.PhoneNumber ?? "").Trim()
            });

            // 2) If we are already signed in to Supabase (no email confirmation needed), save the profile now.
            //    Otherwise it is created the first time they sign in.
            if (!string.IsNullOrEmpty(session.AccessToken))
            {
                try { await CreateProfileAsync(session); }
                catch (SupabaseException ex)
                {
                    // The account exists, so do not leave them stuck on this page: sign-in will try again.
                    _logger.LogWarning(ex, "Account created but the profile could not be saved yet.");
                }
            }

            // 3) Always send them to the sign-in page.
            TempData["FlashSuccess"] = string.IsNullOrEmpty(session.AccessToken)
                ? "Account created. Check your email to confirm it, then sign in."
                : "Registration successful. Please sign in. If you requested staff access, an admin will review your request.";
            return RedirectToAction(nameof(Login));
        }
        catch (SupabaseException ex)
        {
            ModelState.AddModelError("", ex.Message);
            return View(model);
        }
        catch (HttpRequestException)
        {
            ModelState.AddModelError("", "Could not reach Supabase. Check your internet connection.");
            return View(model);
        }
    }

    /// <summary>
    /// Saves the person's profile row using their own Supabase token (they have no cookie yet).
    /// The details come from what they typed at registration. A profile that already exists is fine.
    /// </summary>
    private async Task CreateProfileAsync(SupabaseSession session)
    {
        var user = session.User;
        var requested = user.Meta("requested_role") switch
        {
            Roles.Psychologist => Roles.Psychologist,
            Roles.Admin => Roles.Admin,
            _ => Roles.Student
        };
        var name = user.Meta("display_name");
        if (string.IsNullOrWhiteSpace(name)) name = (user.Email ?? "").Split('@')[0];

        try
        {
            await _db.InsertAsync<object>("profiles", new
            {
                id = user.Id,
                email = user.Email,
                display_name = name,
                requested_role = requested,
                role_request_status = requested == Roles.Student ? "none" : "pending",   // staff requests wait for an admin
                student_number = user.Meta("student_number"),
                phone_number = user.Meta("phone_number")
            }, session.AccessToken);
        }
        catch (SupabaseException ex) when (ex.Code == "23505")
        {
            // 23505 = duplicate key: the profile is already there, nothing to do.
        }
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true) return RedirectToAction("Index", "Home");
        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);

        try
        {
            var session = await _auth.SignInAsync(model.Email, model.Password);
            var profile = await _profiles.GetProfileAsync(session.User.Id, session.AccessToken);

            // First sign-in after registering (for example after confirming the email): build the profile now.
            if (profile == null)
            {
                await CreateProfileAsync(session);
                profile = await _profiles.GetProfileAsync(session.User.Id, session.AccessToken);
            }

            if (profile == null)
            {
                ModelState.AddModelError("", "Your account has no profile yet. Ask the admin to run supabase/schema.sql.");
                return View(model);
            }

            // Allow students to sign in as well. Role-based access to pages is enforced via [Authorize] on controllers.
            // If you want to restrict student access to certain pages, keep using role attributes on controllers/actions.

            await _session.SignInAsync(session, profile);

            // Log for diagnostics and set a brief flash so the browser shows the role after login.
            _logger.LogInformation("User {UserId} signed in with role {Role}", session.User.Id, profile?.Role);
            TempData["FlashSuccess"] = $"Signed in as {profile?.Role}";

            if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                return Redirect(model.ReturnUrl);

            // Redirect students to their dashboard after login
            if (profile?.Role == Roles.Student)
                return RedirectToAction("Index", "Dashboard", new { area = "Student" });

            // Default: go to home page for other roles
            return RedirectToAction("Index", "Home");
        }
        catch (SupabaseException ex)
        {
            ModelState.AddModelError("", ex.Message);
            return View(model);
        }
        catch (HttpRequestException)
        {
            ModelState.AddModelError("", "Could not reach Supabase. Check your internet connection.");
            return View(model);
        }
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        var token = User.FindFirstValue(SupabaseSessionStore.AccessTokenClaim);
        if (!string.IsNullOrEmpty(token)) await _auth.SignOutAsync(token);
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult ForgotPassword() => View(new ForgotPasswordViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        try
        {
            await _auth.SendPasswordResetAsync(model.Email);
        }
        catch (SupabaseException)
        {
            // Don't reveal whether the email exists.
        }
        TempData[Flash.Success] = "If that email has an account, a reset link is on its way.";
        return RedirectToAction(nameof(Login));
    }

    [HttpGet]
    public IActionResult AccessDenied() => View();
}
