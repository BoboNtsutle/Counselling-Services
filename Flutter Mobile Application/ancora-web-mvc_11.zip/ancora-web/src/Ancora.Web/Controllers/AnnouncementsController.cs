using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Controllers;

/// <summary>
/// "Messages and announcements" for students: short personal notices about their appointments,
/// then the news the admin published. URL: /Announcements
/// </summary>
[Authorize]
public class AnnouncementsController : Controller
{
    private readonly AnnouncementService _service;
    private readonly ProfileService _profiles;

    public AnnouncementsController(AnnouncementService service, ProfileService profiles)
    {
        _service = service;
        _profiles = profiles;
    }

    public async Task<IActionResult> Index()
    {
        var model = new AnnouncementsPageViewModel { News = await _service.GetAllAsync() };

        // Personal notices are built from the student's own appointments (no extra table needed).
        if (User.IsInRole(Roles.Student))
        {
            var mine = await _profiles.GetMyAppointmentsAsync(User.GetUserId());
            model.Notices = mine
                .Where(a => a.Status == AppointmentStatus.Approved || a.Status == AppointmentStatus.Rejected || a.Status == AppointmentStatus.Cancelled)
                .OrderByDescending(a => a.UpdatedAt)
                .Take(5)
                .Select(a => new Notice
                {
                    When = a.UpdatedAt,
                    Text = a.Status == AppointmentStatus.Approved
                        ? $"Your appointment on {a.AppointmentDate} at {a.AppointmentTime} is confirmed."
                        : a.Status == AppointmentStatus.Cancelled
                            ? $"You cancelled your appointment on {a.AppointmentDate} at {a.AppointmentTime}."
                            : $"Your appointment request for {a.AppointmentDate} at {a.AppointmentTime} could not be accommodated."
                })
                .ToList();
        }

        return View(model);
    }
}
