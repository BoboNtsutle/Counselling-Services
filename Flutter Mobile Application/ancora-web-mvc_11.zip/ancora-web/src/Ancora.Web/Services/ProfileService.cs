using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services.Supabase;

namespace Ancora.Web.Services;

/// <summary>
/// MODULE 1 — Foundation, Login &amp; My Profile (FR-01, FR-10)
/// Owner: see TEAM-PLAN.md
/// </summary>
public class ProfileService
{
    private readonly SupabaseClient _db;

    public ProfileService(SupabaseClient db) => _db = db;

    /// <summary>Loads a profile row. accessToken is only passed during login (before the cookie exists).</summary>
    public Task<Profile?> GetProfileAsync(Guid userId, string? accessToken = null) =>
        _db.GetSingleAsync<Profile>("profiles", $"id=eq.{userId}", accessToken);

    // ------------------------------------------------------------------
    //  Which times on a date are already taken (shown on the student's booking page)
    // ------------------------------------------------------------------

    // One row from the database function approved_slots() (see supabase/booked_slots.sql).
    private class ApprovedSlot
    {
        [System.Text.Json.Serialization.JsonPropertyName("appointment_date")] public string AppointmentDate { get; set; } = "";
        [System.Text.Json.Serialization.JsonPropertyName("appointment_time")] public string AppointmentTime { get; set; } = "";
        [System.Text.Json.Serialization.JsonPropertyName("psychologist_id")] public Guid PsychologistId { get; set; }
    }

    // One row from the database function days_off_all().
    private class DayOffRow
    {
        [System.Text.Json.Serialization.JsonPropertyName("psychologist_id")] public Guid PsychologistId { get; set; }
        [System.Text.Json.Serialization.JsonPropertyName("off_date")] public string OffDate { get; set; } = "";
    }

    /// <summary>
    /// The hours of one day that cannot be chosen, and why:
    ///   Booked = every psychologist who works that day is already booked at that hour (or all are off)
    ///   Mine   = this student already has a request or session at that hour
    ///   Past   = the hour has already gone by
    /// If the database functions are not installed yet, only Mine and Past are returned (booking still works).
    /// </summary>
    public async Task<Dictionary<string, string>> GetUnavailableSlotsAsync(Guid studentId, DateTime date)
    {
        var result = new Dictionary<string, string>();
        date = date.Date;

        // Hours that have already passed today (and everything on earlier days).
        foreach (var slot in WorkingHours.Slots)
            if (date.AddHours(int.Parse(slot.Substring(0, 2))) <= DateTime.Now) result[slot] = "Past";

        // This student's own open requests / sessions.
        var mine = await GetMyAppointmentsAsync(studentId);
        foreach (var a in mine.Where(a => a.Status == AppointmentStatus.Pending || a.Status == AppointmentStatus.Approved))
            if (a.TryGetSchedule(out var day, out var slot) && day == date && !result.ContainsKey(slot)) result[slot] = "Mine";

        try
        {
            var psychologists = await _db.GetAsync<Profile>("profiles", "role=eq.psychologist&select=id");
            var off = await _db.RpcAsync<DayOffRow>("days_off_all");
            var approved = await _db.RpcAsync<ApprovedSlot>("approved_slots");

            // Psychologists who work on this day.
            var offIds = off.Where(o => o.OffDate == date.ToString("yyyy-MM-dd")).Select(o => o.PsychologistId).ToHashSet();
            var working = psychologists.Select(p => p.Id).Where(id => !offIds.Contains(id)).ToHashSet();

            foreach (var slot in WorkingHours.Slots)
            {
                if (result.ContainsKey(slot)) continue;
                var start = date.AddHours(int.Parse(slot.Substring(0, 2)));
                var bookedCount = approved
                    .Where(r => working.Contains(r.PsychologistId))
                    .Where(r => new Appointment { AppointmentDate = r.AppointmentDate, AppointmentTime = r.AppointmentTime }.IsAt(start))
                    .Select(r => r.PsychologistId).Distinct().Count();

                // Nobody works that day, or everyone who does is already booked at this hour.
                if (working.Count == 0 || bookedCount >= working.Count) result[slot] = "Booked";
            }
        }
        catch (SupabaseException)
        {
            // The functions have not been created yet: skip the "Booked" highlight.
        }

        return result;
    }

    /// <summary>Appointments for a given student.</summary>
    public Task<List<Appointment>> GetMyAppointmentsAsync(Guid studentId) =>
        _db.GetAsync<Appointment>("appointments", $"student_id=eq.{studentId}&order=appointment_date,appointment_time");

    /// <summary>
    /// Saves a new appointment request for a student. It starts as "Pending";
    /// the admin later approves it and assigns a psychologist.
    /// </summary>
    public Task BookAppointmentAsync(Profile student, BookSessionViewModel form)
    {
        // The "reason" column holds the category, plus the student's own words if they wrote any.
        var reason = form.ProblemCategory ?? "";
        if (!string.IsNullOrWhiteSpace(form.Description))
            reason += ": " + form.Description.Trim();

        return _db.InsertAsync<Appointment>("appointments", new
        {
            student_id = student.Id,
            student_name = student.DisplayName,
            student_number = student.StudentNumber,
            course = student.Course,
            appointment_date = form.AppointmentDate!.Value.ToString("yyyy-MM-dd"),
            appointment_time = form.AppointmentTime,          // already "08:00" style text
            reason,
            mood = form.Mood ?? "",
            urgency = form.Urgency,
            status = AppointmentStatus.Pending,
            created_at = DateTimeOffset.UtcNow
        });
    }

    /// <summary>
    /// The student cancels their own appointment (status becomes Cancelled).
    /// Only Pending or Approved ones can be cancelled. Throws InvalidOperationException with a clear
    /// reason when nothing was changed, so the page never claims "cancelled" when it was not.
    /// </summary>
    public async Task CancelAppointmentAsync(Guid appointmentId, Guid studentId)
    {
        // Only this student's own, still-open appointment.
        var filter = $"id=eq.{appointmentId}&student_id=eq.{studentId}" +
                     $"&status=in.({AppointmentStatus.Pending},{AppointmentStatus.Approved})";

        int changed;
        try
        {
            changed = await _db.UpdateAndCountAsync("appointments", filter, new { status = AppointmentStatus.Cancelled });
        }
        catch (SupabaseException ex) when (ex.Code == "23514" || ex.Code == "P0001")
        {
            // The database does not know "Cancelled" yet (supabase/update_cancelled_and_days_off.sql has not been run).
            // Fall back to the old behaviour so cancelling still works.
            changed = await _db.UpdateAndCountAsync("appointments", filter, new { status = AppointmentStatus.Rejected });
        }

        if (changed == 0)
            throw new InvalidOperationException(
                "This appointment could not be cancelled. It may already be closed, or the database does not allow it yet " +
                "(run supabase/schema.sql in the Supabase SQL Editor).");
    }

    // TODO (Module 1): let a user update their own display_name and phone_number.
    // Hint:
    //   await _db.UpdateAsync("profiles", $"id=eq.{userId}",
    //       new { display_name = displayName.Trim(), phone_number = phone.Trim() });
    // The database blocks users from changing their own role, so you only send these two fields.
    public Task UpdateMyProfileAsync(Guid userId, string displayName, string phoneNumber, string bio) =>
        _db.UpdateAsync("profiles", $"id=eq.{userId}", new { display_name = displayName.Trim(), phone_number = phoneNumber.Trim(), bio = bio.Trim() });
}
