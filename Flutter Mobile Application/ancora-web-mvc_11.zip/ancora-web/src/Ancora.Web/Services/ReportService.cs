using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services.Supabase;

namespace Ancora.Web.Services;

/// <summary>Numbers for the admin dashboard cards.</summary>
public class DashboardCounts
{
    public int Pending { get; set; }
    public int Approved { get; set; }
    public int CompletedThisMonth { get; set; }
    public int PendingRoleRequests { get; set; }
}

/// <summary>
/// MODULE 6 — Admin dashboard, statistics &amp; reports (FR-11)
/// The SRS says statistics are NON-graphical (raw numbers/tables) — graphs are "Won't have".
/// Owner: see TEAM-PLAN.md
/// </summary>
public class ReportService
{
    private readonly SupabaseClient _db;

    public ReportService(SupabaseClient db) => _db = db;

    public async Task<DashboardCounts> GetDashboardCountsAsync()
    {
        var counts = new DashboardCounts
        {
            // Done as an example of CountAsync:
            Pending = await _db.CountAsync("appointments", $"status=eq.{AppointmentStatus.Pending}"),
        };
        // Fill remaining dashboard counts
        counts.Approved = await _db.CountAsync("appointments", $"status=eq.{AppointmentStatus.Approved}");
        counts.PendingRoleRequests = await _db.CountAsync("profiles", "role_request_status=eq.pending");
        var firstOfMonth = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1).ToString("yyyy-MM-dd");
        counts.CompletedThisMonth = await _db.CountAsync("appointments", $"status=eq.{AppointmentStatus.Complete}&updated_at=gte.{firstOfMonth}");
        return counts;
    }

    /// <summary>
    /// FR-11: plain counts (no graphs) for an optional date range, based on when the request was made.
    /// </summary>
    public async Task<ReportSummary> GetStatisticsAsync(DateTime? from, DateTime? to)
    {
        var query = new List<string> { "select=status,urgency,psychologist_name,created_at" };
        if (from.HasValue) query.Add($"created_at=gte.{from.Value:yyyy-MM-dd}");
        if (to.HasValue) query.Add($"created_at=lt.{to.Value.AddDays(1):yyyy-MM-dd}");   // include the whole "to" day

        var all = await _db.GetAsync<Appointment>("appointments", string.Join("&", query));

        return new ReportSummary
        {
            Total = all.Count,
            Urgent = all.Count(a => a.Urgency == Urgency.Urgent),
            ByStatus = AppointmentStatus.All
                .Select(st => new StatRow { Label = st, Count = all.Count(a => a.Status == st) }).ToList(),
            ByUrgency = new[] { Urgency.Routine, Urgency.Soon, Urgency.Urgent }
                .Select(u => new StatRow { Label = u, Count = all.Count(a => a.Urgency == u) }).ToList(),
            ByPsychologist = all
                .GroupBy(a => string.IsNullOrEmpty(a.PsychologistName) ? "Not assigned" : a.PsychologistName)
                .Select(g => new StatRow { Label = g.Key, Count = g.Count() })
                .OrderByDescending(r => r.Count).ToList(),
            ByMonth = all
                .GroupBy(a => a.CreatedAt.ToString("yyyy-MM"))
                .Select(g => new StatRow { Label = g.Key, Count = g.Count() })
                .OrderBy(r => r.Label).ToList()
        };
    }
}

/// <summary>The numbers shown on the Reports and statistics page.</summary>
public class ReportSummary
{
    public int Total { get; set; }
    public int Urgent { get; set; }
    public List<StatRow> ByStatus { get; set; } = new();
    public List<StatRow> ByUrgency { get; set; } = new();
    public List<StatRow> ByPsychologist { get; set; } = new();
    public List<StatRow> ByMonth { get; set; } = new();
}
