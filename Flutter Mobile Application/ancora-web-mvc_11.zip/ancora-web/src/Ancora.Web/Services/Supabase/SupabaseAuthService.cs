using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Options;

namespace Ancora.Web.Services.Supabase;

/// <summary>What Supabase Auth gives back after a successful sign-in.</summary>
public class SupabaseSession
{
    [JsonPropertyName("access_token")] public string AccessToken { get; set; } = "";
    [JsonPropertyName("refresh_token")] public string RefreshToken { get; set; } = "";
    [JsonPropertyName("expires_at")] public long ExpiresAt { get; set; }   // unix seconds
    [JsonPropertyName("user")] public SupabaseUser User { get; set; } = new();
}

public class SupabaseUser
{
    [JsonPropertyName("id")] public Guid Id { get; set; }
    [JsonPropertyName("email")] public string Email { get; set; } = "";

    /// <summary>The details sent at registration (name, requested role, ...). Used to build the profile at first sign-in.</summary>
    [JsonPropertyName("user_metadata")] public JsonElement UserMetadata { get; set; }

    /// <summary>One value from user_metadata, or "" when it is not there.</summary>
    public string Meta(string key) =>
        UserMetadata.ValueKind == JsonValueKind.Object &&
        UserMetadata.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.String
            ? v.GetString() ?? ""
            : "";
}

/// <summary>
/// Talks to Supabase Auth (GoTrue) at {Url}/auth/v1.
/// Same accounts as the Flutter app — a psychologist can log into both with one password.
/// </summary>
public class SupabaseAuthService
{
    private readonly HttpClient _http;
    private readonly SupabaseOptions _options;

    public SupabaseAuthService(HttpClient http, IOptions<SupabaseOptions> options)
    {
        _http = http;
        _options = options.Value;
    }

    public Task<SupabaseSession> SignInAsync(string email, string password) =>
        PostForSessionAsync("auth/v1/token?grant_type=password", new { email = email.Trim(), password });

    /// <summary>
    /// Creates the account. "data" is stored with the user (name, requested role, ...), so the profile can still be
    /// built later if Supabase asks the person to confirm their email first (then there is no session yet).
    /// </summary>
    public async Task<SupabaseSession> SignUpAsync(string email, string password, object? data = null)
    {
        using var request = NewRequest(HttpMethod.Post, "auth/v1/signup");
        request.Content = ToJson(new { email = email.Trim(), password, data });
        using var response = await _http.SendAsync(request);
        var text = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode) throw SupabaseException.From(response.StatusCode, text);

        // With "confirm email" OFF Supabase returns a session ({ access_token, user }).
        // With it ON it returns just the user, so there is no access token.
        using var doc = JsonDocument.Parse(text);
        if (doc.RootElement.TryGetProperty("access_token", out _))
            return JsonSerializer.Deserialize<SupabaseSession>(text)
                   ?? throw new SupabaseException("Registration failed. Try again.", response.StatusCode);

        var user = JsonSerializer.Deserialize<SupabaseUser>(text)
                   ?? throw new SupabaseException("Registration failed. Try again.", response.StatusCode);
        return new SupabaseSession { User = user };
    }

    public Task<SupabaseSession> RefreshAsync(string refreshToken) =>
        PostForSessionAsync("auth/v1/token?grant_type=refresh_token", new { refresh_token = refreshToken });

    /// <summary>Sends the "reset your password" email.</summary>
    public async Task SendPasswordResetAsync(string email)
    {
        using var request = NewRequest(HttpMethod.Post, "auth/v1/recover");
        request.Content = ToJson(new { email = email.Trim() });
        using var response = await _http.SendAsync(request);
        if (!response.IsSuccessStatusCode)
            throw SupabaseException.From(response.StatusCode, await response.Content.ReadAsStringAsync());
    }

    /// <summary>Changes the signed-in user's password.</summary>
    public async Task UpdatePasswordAsync(string accessToken, string newPassword)
    {
        using var request = NewRequest(HttpMethod.Put, "auth/v1/user");
        request.Headers.Authorization = new("Bearer", accessToken);
        request.Content = ToJson(new { password = newPassword });
        using var response = await _http.SendAsync(request);
        if (!response.IsSuccessStatusCode)
            throw SupabaseException.From(response.StatusCode, await response.Content.ReadAsStringAsync());
    }

    /// <summary>Ends the session on Supabase's side too (best effort).</summary>
    public async Task SignOutAsync(string accessToken)
    {
        using var request = NewRequest(HttpMethod.Post, "auth/v1/logout");
        request.Headers.Authorization = new("Bearer", accessToken);
        try { using var _ = await _http.SendAsync(request); } catch (HttpRequestException) { }
    }

    private async Task<SupabaseSession> PostForSessionAsync(string path, object body)
    {
        using var request = NewRequest(HttpMethod.Post, path);
        request.Content = ToJson(body);
        using var response = await _http.SendAsync(request);
        var text = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode) throw SupabaseException.From(response.StatusCode, text);
        return JsonSerializer.Deserialize<SupabaseSession>(text)
               ?? throw new SupabaseException("Sign-in failed. Try again.", response.StatusCode);
    }

    private static StringContent ToJson(object body) => SupabaseClient.ToJson(body);

    private HttpRequestMessage NewRequest(HttpMethod method, string path)
    {
        var request = new HttpRequestMessage(method, $"{_options.Url.TrimEnd('/')}/{path}");
        request.Headers.Add("apikey", _options.PublishableKey);
        return request;
    }
}
