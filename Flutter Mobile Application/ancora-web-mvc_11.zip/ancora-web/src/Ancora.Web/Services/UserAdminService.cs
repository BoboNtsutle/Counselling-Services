using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services.Supabase;

namespace Ancora.Web.Services;

/// <summary>
/// MODULE 3 — Admin: Users, role requests &amp; student records (FR-06, FR-07, FR-10)
/// Owner: see TEAM-PLAN.md
/// </summary>
public class UserAdminService
{
    private readonly SupabaseClient _db;

    public UserAdminService(SupabaseClient db) => _db = db;

    /// <summary>People who registered in the Flutter app and asked to be a psychologist or admin.</summary>
    public Task<List<Profile>> GetPendingRoleRequestsAsync() =>
        _db.GetAsync<Profile>("profiles", "role_request_status=eq.pending&order=created_at");

    public Task<List<Profile>> GetByRoleAsync(string role) =>
        _db.GetAsync<Profile>("profiles", $"role=eq.{role}&order=display_name");

    /// <summary>
    /// Approve a staff access request: the person becomes a psychologist, or an admin if that is the role approved.
    /// Same as reviewRoleRequest in the Flutter app.
    /// </summary>
    public Task ApproveRoleRequestAsync(Guid userId, string approvedRole)
    {
        // Staff access only: psychologist (default) or admin.
        if (approvedRole != Roles.Admin) approvedRole = Roles.Psychologist;
        return SaveAsync(userId, new { role = approvedRole, role_request_status = "approved" });
    }

    /// <summary>Reject a staff access request: the person stays a student.</summary>
    public Task RejectRoleRequestAsync(Guid userId) =>
        SaveAsync(userId, new { role = Roles.Student, role_request_status = "rejected" });

    // Saves the change and checks that a row really changed.
    // (When a database rule blocks the update, Supabase answers "success" with 0 rows.)
    private async Task SaveAsync(Guid userId, object changes)
    {
        var changed = await _db.UpdateAndCountAsync("profiles", $"id=eq.{userId}", changes);
        if (changed == 0)
            throw new InvalidOperationException("Nothing was saved. Check that your account is an admin and that the profiles rules in Supabase were run.");
    }

    /// <summary>Total number of students (admin dashboard).</summary>
    public Task<int> CountStudentsAsync() =>
        _db.CountAsync("profiles", $"role=eq.{Roles.Student}");

    /// <summary>One student's profile row, or null.</summary>
    public Task<Profile?> GetStudentAsync(Guid studentId) =>
        _db.GetSingleAsync<Profile>("profiles", $"id=eq.{studentId}&role=eq.{Roles.Student}");

    /// <summary>Admin edits a student's details. Only these four fields can be changed here.</summary>
    public Task UpdateStudentAsync(Guid studentId, string displayName, string studentNumber, string course, string phone) =>
        _db.UpdateAsync("profiles", $"id=eq.{studentId}&role=eq.{Roles.Student}", new
        {
            display_name = displayName.Trim(),
            student_number = studentNumber.Trim(),
            course = course.Trim(),
            phone_number = phone.Trim()
        });

    /// <summary>
    /// FR-07: search students by name, student number or email.
    /// An empty search returns every student (first 100), so the page is never blank.
    /// </summary>
    public Task<List<Profile>> SearchStudentsAsync(string? term)
    {
        var query = $"role=eq.{Roles.Student}&order=display_name&limit=100";

        if (!string.IsNullOrWhiteSpace(term))
        {
            // Characters that have a special meaning inside a PostgREST "or=(...)" filter are removed.
            var clean = term.Trim().Replace(",", " ").Replace("(", " ").Replace(")", " ").Replace("*", " ");
            var t = Uri.EscapeDataString(clean);
            query += $"&or=(display_name.ilike.*{t}*,student_number.ilike.*{t}*,email.ilike.*{t}*)";
        }

        return _db.GetAsync<Profile>("profiles", query);
    }

    /// <summary>
    /// FR-06: one student's record = their profile + their appointment history (newest first).
    /// Returns null when the id is not a student.
    /// </summary>
    public async Task<StudentRecordViewModel?> GetStudentRecordAsync(Guid studentId)
    {
        var profile = await _db.GetSingleAsync<Profile>("profiles", $"id=eq.{studentId}&role=eq.{Roles.Student}");
        if (profile == null) return null;

        var appointments = await _db.GetAsync<Appointment>("appointments",
            $"student_id=eq.{studentId}&order=created_at.desc");

        return new StudentRecordViewModel { Student = profile, Appointments = appointments };
    }
}
