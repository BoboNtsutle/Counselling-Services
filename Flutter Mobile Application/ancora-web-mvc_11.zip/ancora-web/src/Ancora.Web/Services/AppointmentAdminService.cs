using Ancora.Web.Models;
using Ancora.Web.Services.Supabase;

namespace Ancora.Web.Services;

/// <summary>
/// MODULE 2 — Admin: Appointment management + double-booking guard (FR-03, FR-04)
/// Owner: see TEAM-PLAN.md
/// </summary>
public class AppointmentAdminService
{
    private readonly SupabaseClient _db;
    private readonly TimeOffService _timeOff;

    public AppointmentAdminService(SupabaseClient db, TimeOffService timeOff)
    {
        _db = db;
        _timeOff = timeOff;
    }

    /// <summary>
    /// All appointments, newest first: the latest date and time at the top, the oldest at the bottom.
    /// Pass a status to filter (Pending, Approved, ...).
    /// </summary>
    public async Task<List<Appointment>> GetAllAsync(string? status = null)
    {
        var query = "order=created_at.desc";
        if (!string.IsNullOrWhiteSpace(status)) query = $"status=eq.{Uri.EscapeDataString(status)}&{query}";
        var rows = await _db.GetAsync<Appointment>("appointments", query);
        // Requests (Pending) are shown by when they were sent; everything else by session date and time.
        return status == AppointmentStatus.Pending ? rows.RequestsNewestFirst() : rows.NewestFirst();
    }

    /// <summary>
    /// Saves a change to one appointment and checks that a row was REALLY changed.
    /// (If the database refuses, Supabase answers "OK" and changes nothing, which used to look like a success.)
    /// </summary>
    private async Task SaveAsync(Guid appointmentId, object changes)
    {
        var changed = await _db.UpdateAndCountAsync("appointments", $"id=eq.{appointmentId}", changes);
        if (changed == 0)
            throw new InvalidOperationException(
                "The change was not saved: the database refused it. Run supabase/schema.sql in the Supabase SQL Editor, then try again.");
    }

    /// <summary>A cancelled, declined, finished or missed appointment cannot be approved or moved any more.</summary>
    public static void EnsureOpen(Appointment ap)
    {
        if (ap.Status != AppointmentStatus.Pending && ap.Status != AppointmentStatus.Approved)
            throw new InvalidOperationException($"This appointment is {ap.Status.ToLower()}, so it can no longer be changed.");
    }

    /// <summary>Throws a clear message when the psychologist has switched that day off.</summary>
    private async Task EnsureWorkingDayAsync(Guid psychologistId, string date)
    {
        var off = await _timeOff.GetDayOffAsync(psychologistId, date);
        if (off != null)
            throw new InvalidOperationException($"That psychologist is off on {date} ({off.Reason}). Please choose another day.");
    }

    /// <summary>
    /// Admin clicked a FREE time on the availability calendar: take a Pending request, move it to
    /// that day and hour, give it to that psychologist and approve it, all in one step.
    /// </summary>
    public async Task BookIntoSlotAsync(Guid appointmentId, Guid psychologistId, string date, string time)
    {
        var start = ReadSlot(date, time);   // checks weekday, listed hour and "not in the past"

        var ap = await GetByIdAsync(appointmentId);
        if (ap == null) throw new InvalidOperationException("Appointment not found.");
        if (ap.Status != AppointmentStatus.Pending)
            throw new InvalidOperationException("Only a pending request can be booked into a free time.");

        await EnsureWorkingDayAsync(psychologistId, date);

        if (await IsSlotTakenAsync(psychologistId, start, appointmentId))
            throw new InvalidOperationException("That time has just been taken. Please pick another one.");

        await SaveAsync(appointmentId, new
        {
            psychologist_id = psychologistId,
            appointment_date = date,
            appointment_time = time,
            status = AppointmentStatus.Approved
        });
    }

    /// <summary>True if this psychologist already has an Approved appointment starting at that hour.</summary>
    public async Task<bool> IsSlotTakenAsync(Guid psychologistId, DateTime start, Guid? ignoreAppointmentId = null)
    {
        var approved = await _db.GetAsync<Appointment>("appointments",
            $"psychologist_id=eq.{psychologistId}&status=eq.{AppointmentStatus.Approved}");
        // Compare real dates, so older "Fri, Oct 9" / "9:00 AM" rows are recognised too.
        return approved.Any(a => a.Id != ignoreAppointmentId && a.IsAt(start));
    }

    /// <summary>Turns "2026-10-12" + "09:00" into a date-time, or explains what is wrong with it.</summary>
    public static DateTime ReadSlot(string? date, string? time)
    {
        if (!DateTime.TryParseExact(date, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out var day))
            throw new InvalidOperationException("That date is not valid.");
        if (!WorkingHours.IsWorkingDay(day))
            throw new InvalidOperationException("The centre is open Monday to Friday.");
        if (time == null || !WorkingHours.Slots.Contains(time))
            throw new InvalidOperationException("Please choose one of the listed hours.");

        var start = day.Date.AddHours(int.Parse(time.Substring(0, 2)));
        if (start < DateTime.Now)
            throw new InvalidOperationException("That time is already in the past.");
        return start;
    }

    public Task<Appointment?> GetByIdAsync(Guid id) =>
        _db.GetSingleAsync<Appointment>("appointments", $"id=eq.{id}");

    /// <summary>Psychologists for the "assign to" dropdown.</summary>
    public Task<List<Profile>> GetPsychologistsAsync() =>
        _db.GetAsync<Profile>("profiles", $"role=eq.{Roles.Psychologist}&order=display_name");

    // TODO (Module 2): FR-04 double-booking guard.
    // Return true if the psychologist already has an APPROVED appointment on the same date + time.
    // Hint:
    //   var clashes = await _db.GetAsync<Appointment>("appointments",
    //       $"psychologist_id=eq.{psychologistId}&status=eq.Approved" +
    //       $"&appointment_date=eq.{Uri.EscapeDataString(date)}" +
    //       $"&appointment_time=eq.{Uri.EscapeDataString(time)}" +
    //       $"&id=neq.{excludeAppointmentId}");
    //   return clashes.Count > 0;
    public async Task<bool> HasClashAsync(Guid psychologistId, string date, string time, Guid excludeAppointmentId)
    {
        // Return true if the psychologist already has an APPROVED appointment on the same date + time.
        var clashes = await _db.GetAsync<Appointment>("appointments",
            $"psychologist_id=eq.{psychologistId}&status=eq.{AppointmentStatus.Approved}" +
            $"&appointment_date=eq.{Uri.EscapeDataString(date)}" +
            $"&appointment_time=eq.{Uri.EscapeDataString(time)}" +
            $"&id=neq.{excludeAppointmentId}");
        return clashes.Count > 0;
    }

    // TODO (Module 2): assign a psychologist and approve.
    // 1. Load the appointment.  2. If HasClashAsync(...) → throw/return an error message.
    // 3. await _db.UpdateAsync("appointments", $"id=eq.{id}",
    //        new { psychologist_id = psychologistId, status = AppointmentStatus.Approved });
    // (The database trigger fills in psychologist_name for you.)
    public async Task AssignAndApproveAsync(Guid appointmentId, Guid psychologistId)
    {
        var ap = await GetByIdAsync(appointmentId);
        if (ap == null) throw new InvalidOperationException("Appointment not found.");
        EnsureOpen(ap);

        var date = ap.AppointmentDate;
        var time = ap.AppointmentTime;

        // The psychologist must not be off on the requested day, and must not already have someone at that hour.
        if (ap.TryGetSchedule(out var day, out _))
            await EnsureWorkingDayAsync(psychologistId, day.ToString("yyyy-MM-dd"));
        if (await HasClashAsync(psychologistId, date, time, appointmentId))
            throw new InvalidOperationException("That psychologist is already booked for that slot.");
        if (ap.Start() is DateTime start && await IsSlotTakenAsync(psychologistId, start, appointmentId))
            throw new InvalidOperationException("That psychologist is already booked for that slot.");

        await SaveAsync(appointmentId, new { psychologist_id = psychologistId, status = AppointmentStatus.Approved });
    }

    // TODO (Module 2): reject a request → status = Rejected.
    public Task RejectAsync(Guid appointmentId) =>
        SaveAsync(appointmentId, new { status = AppointmentStatus.Rejected });

    // TODO (Module 2): reschedule → change appointment_date / appointment_time
    // (run HasClashAsync first if a psychologist is already assigned).
    public async Task RescheduleAsync(Guid appointmentId, string newDate, string newTime)
    {
        var ap = await GetByIdAsync(appointmentId);
        if (ap == null) throw new InvalidOperationException("Appointment not found.");
        EnsureOpen(ap);

        if (ap.PsychologistId != null)
        {
            // Not on a day the psychologist has switched off, and not on top of another session.
            await EnsureWorkingDayAsync(ap.PsychologistId.Value, newDate);
            if (await HasClashAsync(ap.PsychologistId.Value, newDate, newTime, appointmentId))
                throw new InvalidOperationException("Reschedule would cause a double booking for the assigned psychologist.");
        }

        await SaveAsync(appointmentId, new { appointment_date = newDate, appointment_time = newTime });
    }
}
