using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services.Supabase;

namespace Ancora.Web.Services;

/// <summary>
/// MODULE 5 — Psychologist portal: my appointments, status updates, session notes (FR-05, FR-09)
/// Owner: see TEAM-PLAN.md
/// </summary>
public class PsychologistService
{
    private readonly SupabaseClient _db;

    public PsychologistService(SupabaseClient db) => _db = db;

    /// <summary>Appointments assigned to this psychologist (Supabase RLS also enforces this).</summary>
    /// <summary>Newest first: the latest date and time at the top, the oldest at the bottom.</summary>
    public async Task<List<Appointment>> GetMyAppointmentsAsync(Guid psychologistId)
    {
        var rows = await _db.GetAsync<Appointment>("appointments", $"psychologist_id=eq.{psychologistId}&order=created_at.desc");
        return rows.NewestFirst();
    }

    public Task<Appointment?> GetMyAppointmentAsync(Guid psychologistId, Guid appointmentId) =>
        _db.GetSingleAsync<Appointment>("appointments", $"id=eq.{appointmentId}&psychologist_id=eq.{psychologistId}");

    // TODO (Module 5): FR-09 update status. The database only lets a psychologist change
    // the status, and only to Approved, Rejected or Complete (see guard_appointment_update in schema.sql).
    //   await _db.UpdateAsync("appointments", $"id=eq.{appointmentId}", new { status = newStatus });
    public async Task UpdateStatusAsync(Guid appointmentId, Guid psychologistId, string newStatus)
    {
        // Load the appointment to validate current state and ownership
        var ap = await _db.GetSingleAsync<Appointment>("appointments", $"id=eq.{appointmentId}");
        if (ap == null) throw new InvalidOperationException("Appointment not found.");
        if (ap.PsychologistId == null || ap.PsychologistId != psychologistId)
            throw new InvalidOperationException("You are not assigned to this appointment.");

        // Enforce allowed transitions:
        // Pending  -> Approved, Rejected
        // Approved -> Complete
        // Complete/Rejected -> no further changes
        var cur = ap.Status ?? "";
        var allowed = cur switch
        {
            AppointmentStatus.Pending => new[] { AppointmentStatus.Approved, AppointmentStatus.Rejected },
            AppointmentStatus.Approved => new[] { AppointmentStatus.Complete },
            _ => Array.Empty<string>()
        };

        if (!allowed.Contains(newStatus))
            throw new InvalidOperationException($"Cannot change status from {cur} to {newStatus}.");

        // Check that a row was REALLY changed (the database may refuse without raising an error).
        var changed = await _db.UpdateAndCountAsync("appointments", $"id=eq.{appointmentId}", new { status = newStatus });
        if (changed == 0)
            throw new InvalidOperationException(
                "The status was not saved: the database refused it. Run supabase/schema.sql in the Supabase SQL Editor, then try again.");
    }

    // TODO (Module 5): load session notes (empty string if none yet).
    //   var note = await _db.GetSingleAsync<ClinicalNote>("clinical_notes", $"appointment_id=eq.{appointmentId}");
    //   return note?.Notes ?? "";
    public Task<string> GetNotesAsync(Guid appointmentId) =>
        _db.GetSingleAsync<ClinicalNote>("clinical_notes", $"appointment_id=eq.{appointmentId}")
            .ContinueWith(t => t.Result?.Notes ?? "");

    // TODO (Module 5): save session notes (insert or update — one note row per appointment).
    //   await _db.UpsertAsync("clinical_notes",
    //       new { appointment_id = appointmentId, notes, updated_at = DateTimeOffset.UtcNow },
    //       onConflict: "appointment_id");
    public Task SaveNotesAsync(Guid appointmentId, string notes) =>
        _db.UpsertAsync("clinical_notes", new { appointment_id = appointmentId, notes, updated_at = DateTimeOffset.UtcNow }, onConflict: "appointment_id");

    /// <summary>
    /// Student records for a psychologist: only students who have an appointment with THEM.
    /// An optional search term matches name, student number or email.
    /// </summary>
    public async Task<List<Profile>> GetMyStudentsAsync(Guid psychologistId, string? term)
    {
        var mine = await GetMyAppointmentsAsync(psychologistId);
        var ids = mine.Select(a => a.StudentId).Distinct().ToList();
        if (ids.Count == 0) return new List<Profile>();

        var students = await _db.GetAsync<Profile>("profiles", $"id=in.({string.Join(",", ids)})&order=display_name");

        if (!string.IsNullOrWhiteSpace(term))
        {
            var t = term.Trim();
            students = students
                .Where(s => Contains(s.DisplayName, t) || Contains(s.StudentNumber, t) || Contains(s.Email, t))
                .ToList();
        }
        return students;
    }

    /// <summary>One assigned student's record, showing only the sessions with this psychologist. Null if not assigned.</summary>
    public async Task<StudentRecordViewModel?> GetMyStudentRecordAsync(Guid psychologistId, Guid studentId)
    {
        var sessions = (await GetMyAppointmentsAsync(psychologistId))
            .Where(a => a.StudentId == studentId)
            .OrderByDescending(a => a.CreatedAt)
            .ToList();
        if (sessions.Count == 0) return null;                       // not one of my students

        var profile = await _db.GetSingleAsync<Profile>("profiles", $"id=eq.{studentId}");
        if (profile == null) return null;

        return new StudentRecordViewModel { Student = profile, Appointments = sessions };
    }

    private static bool Contains(string? text, string term) =>
        (text ?? "").Contains(term, StringComparison.OrdinalIgnoreCase);
}
