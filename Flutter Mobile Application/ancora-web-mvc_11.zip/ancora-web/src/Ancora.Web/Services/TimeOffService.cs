using Ancora.Web.Models;
using Ancora.Web.Services.Supabase;

namespace Ancora.Web.Services;

/// <summary>
/// Days a psychologist has switched off (for example "On leave"). Table: psychologist_time_off.
/// On a day off nobody can be booked with that psychologist, and the availability calendars show the reason.
/// </summary>
public class TimeOffService
{
    private const int MaxReason = 120;

    private readonly SupabaseClient _db;

    public TimeOffService(SupabaseClient db) => _db = db;

    /// <summary>One psychologist's days off, earliest first. Returns an empty list if the table has not been created yet.</summary>
    public async Task<List<TimeOff>> GetAsync(Guid psychologistId)
    {
        try
        {
            return await _db.GetAsync<TimeOff>("psychologist_time_off",
                $"psychologist_id=eq.{psychologistId}&order=off_date");
        }
        catch (SupabaseException ex) when (IsMissingTable(ex))
        {
            return new List<TimeOff>();   // keeps the calendars working until supabase/schema.sql is run
        }
    }

    /// <summary>The day-off row for that psychologist and date ("yyyy-MM-dd"), or null when they are working.</summary>
    public async Task<TimeOff?> GetDayOffAsync(Guid psychologistId, string date)
    {
        try
        {
            return await _db.GetSingleAsync<TimeOff>("psychologist_time_off",
                $"psychologist_id=eq.{psychologistId}&off_date=eq.{Uri.EscapeDataString(date)}");
        }
        catch (SupabaseException ex) when (IsMissingTable(ex))
        {
            return null;
        }
    }

    /// <summary>
    /// Switches off every working day from "from" to "to" (both included), with one reason for all of them.
    /// Weekends are skipped, and days that are already off are left as they are.
    /// Returns how many days were switched off. Throws InvalidOperationException with a clear message if not allowed.
    /// </summary>
    public async Task<int> AddRangeAsync(Guid psychologistId, DateTime from, DateTime to, string? reason)
    {
        from = from.Date;
        to = to.Date;
        if (from < DateTime.Today)
            throw new InvalidOperationException("The first day must be today or later.");
        if (to < from)
            throw new InvalidOperationException("The last day cannot be before the first day.");
        if ((to - from).TotalDays > 366)
            throw new InvalidOperationException("Please switch off at most one year at a time.");

        reason = (reason ?? "").Trim();
        if (reason.Length == 0) reason = "Day off";
        if (reason.Length > MaxReason) reason = reason.Substring(0, MaxReason);

        // The working days in the range (Monday to Friday).
        var days = new List<DateTime>();
        for (var d = from; d <= to; d = d.AddDays(1))
            if (WorkingHours.IsWorkingDay(d)) days.Add(d);
        if (days.Count == 0)
            throw new InvalidOperationException("Those dates are only weekends. The centre is only open Monday to Friday.");

        // Leave days that are already switched off alone.
        var already = (await GetAsync(psychologistId)).Select(t => t.OffDate).ToHashSet();
        var rows = days
            .Where(d => !already.Contains(d.ToString("yyyy-MM-dd")))
            .Select(d => new { psychologist_id = psychologistId, off_date = d.ToString("yyyy-MM-dd"), reason })
            .ToList();
        if (rows.Count == 0)
            throw new InvalidOperationException("Those days are already switched off.");

        try
        {
            // One request saves all the days.
            await _db.InsertAsync<TimeOff>("psychologist_time_off", rows);
        }
        catch (SupabaseException ex) when (IsMissingTable(ex))
        {
            throw new InvalidOperationException("The days-off table is missing. Run supabase/schema.sql in the Supabase SQL Editor.");
        }
        return rows.Count;
    }

    /// <summary>Switches days back on (only the psychologist's own days off can be removed).</summary>
    public Task RemoveAsync(IEnumerable<Guid> ids, Guid psychologistId)
    {
        var list = ids.Distinct().ToList();
        if (list.Count == 0) return Task.CompletedTask;
        return _db.DeleteAsync("psychologist_time_off",
            $"id=in.({string.Join(",", list)})&psychologist_id=eq.{psychologistId}");
    }

    // The table is created by supabase/schema.sql; until then show a hint instead of crashing.
    private static bool IsMissingTable(SupabaseException ex) =>
        ex.Code == "PGRST205" || ex.Code == "42P01" ||
        ex.Message.Contains("tables are missing", StringComparison.OrdinalIgnoreCase);
}
