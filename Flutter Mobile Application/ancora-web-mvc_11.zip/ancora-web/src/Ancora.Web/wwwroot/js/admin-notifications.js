// Admin notifications: a count badge on "Manage appointments" and a pop-up when a NEW request arrives.
// Asks the server every 30 seconds. Loaded only for admins (see _Layout.cshtml).
(function () {
    var url = window.ancoraNotifyUrl;
    if (!url) return;

    var SEEN_KEY = 'ancora.lastAnnouncedRequest';   // id of the last request we already told the admin about
    var originalTitle = document.title;

    // Shows the number on the menu link and in the browser tab title.
    function showCount(n) {
        var badge = document.getElementById('pendingBadge');
        if (badge) {
            badge.textContent = n;
            badge.hidden = n === 0;
        }
        document.title = n > 0 ? '(' + n + ') ' + originalTitle : originalTitle;
    }

    // Small pop-up in the top-right corner. Text is added with textContent so student names cannot inject HTML.
    function showToast(req) {
        var box = document.createElement('div');
        box.className = 'toast-a';
        box.setAttribute('role', 'alert');

        var title = document.createElement('strong');
        title.textContent = 'New appointment request';
        var line = document.createElement('div');
        line.textContent = req.student + ' · ' + req.date + ' ' + req.time + (req.urgency ? ' · ' + req.urgency : '');
        var link = document.createElement('a');
        link.href = req.url;
        link.textContent = 'Open request';
        var close = document.createElement('button');
        close.type = 'button';
        close.setAttribute('aria-label', 'Close');
        close.textContent = '×';
        close.onclick = function () { box.remove(); };

        box.appendChild(close);
        box.appendChild(title);
        box.appendChild(line);
        box.appendChild(link);
        document.body.appendChild(box);
        setTimeout(function () { box.remove(); }, 12000);
    }

    function check() {
        fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                showCount(data.pending);
                if (!data.newest) return;

                var last = null;
                try { last = localStorage.getItem(SEEN_KEY); } catch (e) { }
                if (last !== data.newest.id) {
                    showToast(data.newest);
                    try { localStorage.setItem(SEEN_KEY, data.newest.id); } catch (e) { }
                }
            })
            .catch(function () { /* offline or session ended: try again next time */ });
    }

    check();
    setInterval(check, 30000);
})();
