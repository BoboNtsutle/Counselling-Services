namespace Ancora.Web.Models.ViewModels;

/// <summary>Everything the student dashboard shows.</summary>
public class StudentDashboardViewModel
{
    public Profile? Profile { get; set; }

    /// <summary>Appointments that are still current: Pending or Approved, soonest first.</summary>
    public List<Appointment> Upcoming { get; set; } = new();

    /// <summary>The very next one (first in Upcoming), or null.</summary>
    public Appointment? Next { get; set; }

    /// <summary>How many requests are still waiting for approval.</summary>
    public int PendingCount { get; set; }

    /// <summary>The newest announcements published by the admin.</summary>
    public List<Announcement> News { get; set; } = new();

    /// <summary>Announcements published in the last 7 days.</summary>
    public int NewNewsCount { get; set; }

    // If one part could not be loaded (for example a Supabase permission problem), the page still
    // opens and the matching card shows this message instead of everything breaking.
    public string? ProfileError { get; set; }
    public string? AppointmentsError { get; set; }
    public string? NewsError { get; set; }
}
