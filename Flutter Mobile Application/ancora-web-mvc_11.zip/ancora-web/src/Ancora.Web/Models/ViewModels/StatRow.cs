namespace Ancora.Web.Models.ViewModels;

/// <summary>One line of a statistics table: a label and how many.</summary>
public class StatRow
{
    public string Label { get; set; } = "";
    public int Count { get; set; }
}
