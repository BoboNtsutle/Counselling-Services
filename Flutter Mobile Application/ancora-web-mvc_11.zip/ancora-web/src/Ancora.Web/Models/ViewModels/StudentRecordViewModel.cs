namespace Ancora.Web.Models.ViewModels;

/// <summary>One student's record: who they are + every appointment they have made.</summary>
public class StudentRecordViewModel
{
    public Profile Student { get; set; } = new();
    public List<Appointment> Appointments { get; set; } = new();
}
