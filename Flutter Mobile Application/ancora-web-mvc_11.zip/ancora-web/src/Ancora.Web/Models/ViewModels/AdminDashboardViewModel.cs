namespace Ancora.Web.Models.ViewModels;

/// <summary>Numbers and lists for the admin home page.</summary>
public class AdminDashboardViewModel
{
    public int TotalStudents { get; set; }
    public int Pending { get; set; }
    public int ThisWeek { get; set; }                       // pending/approved appointments this Mon-Sun
    public List<Appointment> Upcoming { get; set; } = new();
    public Announcement? LatestAnnouncement { get; set; }
}
