namespace Ancora.Web.Models.Admin;

/// <summary>
/// One month of availability for ONE psychologist.
/// A slot is "booked" when that psychologist has an Approved appointment at that hour.
/// </summary>
public class AvailabilityViewModel
{
    public int Year { get; set; }
    public int Month { get; set; }

    /// <summary>Everyone in the drop-down, and the one currently shown.</summary>
    public List<Profile> Psychologists { get; set; } = new();
    public Profile? Selected { get; set; }

    /// <summary>Booked slots only: day → ("09:00" → the appointment that fills it).</summary>
    public Dictionary<DateTime, Dictionary<string, Appointment>> Booked { get; set; } = new();

    /// <summary>Days the selected psychologist has switched off: day → the day-off row (with its reason).</summary>
    public Dictionary<DateTime, TimeOff> DaysOff { get; set; } = new();

    /// <summary>All of the selected psychologist's days off, earliest first (used for the list under the calendar).</summary>
    public List<TimeOff> AllDaysOff { get; set; } = new();

    /// <summary>Days off joined into periods ("2 Nov to 6 Nov, On leave"), earliest first.</summary>
    public List<DayOffPeriod> Periods { get; set; } = new();

    /// <summary>Remembers the selected psychologist's days off so the calendar can show them.</summary>
    public void SetDaysOff(List<TimeOff> daysOff)
    {
        AllDaysOff = daysOff.Where(d => d.Day != null).OrderBy(d => d.Day).ToList();
        DaysOff = AllDaysOff.ToDictionary(d => d.Day!.Value, d => d);

        // Join working days that follow each other (Friday to Monday counts) and share the same reason.
        Periods = new List<DayOffPeriod>();
        foreach (var d in AllDaysOff)
        {
            var last = Periods.LastOrDefault();
            if (last != null && last.Reason == d.Reason && NextWorkingDay(last.To) == d.Day!.Value)
            {
                last.To = d.Day.Value;
                last.Ids.Add(d.Id);
                last.Days++;
            }
            else
            {
                Periods.Add(new DayOffPeriod { From = d.Day!.Value, To = d.Day.Value, Reason = d.Reason, Ids = new List<Guid> { d.Id }, Days = 1 });
            }
        }
    }

    private static DateTime NextWorkingDay(DateTime day)
    {
        var next = day.AddDays(1);
        while (!WorkingHours.IsWorkingDay(next)) next = next.AddDays(1);
        return next;
    }

    public static AvailabilityViewModel ForMonth(int year, int month, List<Profile> psychologists,
                                                 Guid? selectedId, List<Appointment> approved)
    {
        var model = new AvailabilityViewModel
        {
            Year = year,
            Month = month,
            Psychologists = psychologists,
            // First psychologist is shown when none was picked.
            Selected = psychologists.FirstOrDefault(p => p.Id == selectedId) ?? psychologists.FirstOrDefault()
        };
        if (model.Selected == null) return model;

        foreach (var appt in approved.Where(a => a.PsychologistId == model.Selected.Id))
        {
            if (!appt.TryGetSchedule(out var date, out var slot)) continue;
            if (date.Year != year || date.Month != month) continue;

            if (!model.Booked.ContainsKey(date.Date)) model.Booked[date.Date] = new();
            model.Booked[date.Date][slot] = appt;
        }
        return model;
    }
}

/// <summary>A run of days off with one reason, for example "2 Nov to 6 Nov, On leave".</summary>
public class DayOffPeriod
{
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public string Reason { get; set; } = "";
    public int Days { get; set; }

    /// <summary>The database rows in this period (so the whole period can be switched back on).</summary>
    public List<Guid> Ids { get; set; } = new();
}
