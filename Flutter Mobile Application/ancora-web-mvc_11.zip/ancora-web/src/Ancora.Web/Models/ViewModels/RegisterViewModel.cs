using System.ComponentModel.DataAnnotations;

namespace Ancora.Web.Models.ViewModels;

public class RegisterViewModel
{
    [Required, EmailAddress]
    public string Email { get; set; } = "";

    [Required, DataType(DataType.Password), MinLength(6)]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Please enter your name.")]
    [Display(Name = "Name")]
    public string DisplayName { get; set; } = "";

    /// <summary>Students only. Psychologists and admins are not asked for it.</summary>
    [Display(Name = "Student number")]
    public string? StudentNumber { get; set; }

    [Required(ErrorMessage = "Please enter your phone number.")]
    [Display(Name = "Phone number")]
    public string? PhoneNumber { get; set; }

    [Required]
    public string RequestedRole { get; set; } = "psychologist"; // psychologist, admin or student
}
