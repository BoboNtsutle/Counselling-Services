namespace Ancora.Web.Models.ViewModels;

/// <summary>"Messages and announcements" page: personal notices (students only) + the published news.</summary>
public class AnnouncementsPageViewModel
{
    public List<Notice> Notices { get; set; } = new();
    public List<Announcement> News { get; set; } = new();
}

/// <summary>A short personal message, such as "Your appointment on 3 Sep is confirmed."</summary>
public class Notice
{
    public string Text { get; set; } = "";
    public DateTimeOffset When { get; set; }
}
