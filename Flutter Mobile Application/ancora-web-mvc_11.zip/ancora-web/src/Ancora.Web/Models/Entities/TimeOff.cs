using System.Text.Json.Serialization;

namespace Ancora.Web.Models;

/// <summary>
/// One row of "psychologist_time_off": a day the psychologist has switched off (for example on leave).
/// Nobody can be booked with them on that day.
/// </summary>
public class TimeOff
{
    [JsonPropertyName("id")] public Guid Id { get; set; }
    [JsonPropertyName("psychologist_id")] public Guid PsychologistId { get; set; }

    /// <summary>The day, written "yyyy-MM-dd".</summary>
    [JsonPropertyName("off_date")] public string OffDate { get; set; } = "";

    /// <summary>Why, for example "Annual leave". Shown next to the day on the calendar.</summary>
    [JsonPropertyName("reason")] public string Reason { get; set; } = "";

    [JsonPropertyName("created_at")] public DateTimeOffset CreatedAt { get; set; }

    /// <summary>The day as a real date (null if the text cannot be read).</summary>
    public DateTime? Day =>
        DateTime.TryParseExact(OffDate, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out var d) ? d.Date : null;
}
