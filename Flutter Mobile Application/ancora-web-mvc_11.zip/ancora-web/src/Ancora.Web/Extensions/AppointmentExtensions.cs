using System.Globalization;

namespace Ancora.Web.Models;

/// <summary>
/// The appointments table stores date and time as TEXT. These helpers turn that text into real values.
/// Works for "2026-10-12" / "09:00" (web) and for "Fri, Oct 9" / "9:00 AM" (older mobile data).
/// </summary>
public static class AppointmentExtensions
{
    /// <summary>Reads the day and the one-hour slot (like "09:00"). Returns false if the text cannot be read.</summary>
    public static bool TryGetSchedule(this Appointment a, out DateTime date, out string slot)
    {
        slot = "";
        if (!DateTime.TryParse(a.AppointmentDate, CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            return false;

        TimeSpan time;
        if (!TimeSpan.TryParse(a.AppointmentTime, CultureInfo.InvariantCulture, out time))
        {
            if (!DateTime.TryParse(a.AppointmentTime, CultureInfo.InvariantCulture, DateTimeStyles.None, out var t))
                return false;
            time = t.TimeOfDay;
        }

        date = date.Date;
        slot = $"{time.Hours:00}:00";   // round down to the hour
        return true;
    }

    /// <summary>The moment the session starts (day plus hour), or null when the text cannot be read.</summary>
    public static DateTime? Start(this Appointment a) =>
        a.TryGetSchedule(out var day, out var slot) ? day.AddHours(int.Parse(slot.Substring(0, 2))) : null;

    /// <summary>
    /// Newest appointment first, by the real date and time of the session (latest day and hour at the top).
    /// Rows whose date cannot be read go to the bottom.
    /// </summary>
    public static List<Appointment> NewestFirst(this IEnumerable<Appointment> list) =>
        list.OrderByDescending(a => a.Start() ?? DateTime.MinValue)
            .ThenByDescending(a => a.CreatedAt)
            .ToList();

    /// <summary>
    /// Appointment REQUESTS: the most recently submitted request first (by when the student sent it).
    /// </summary>
    public static List<Appointment> RequestsNewestFirst(this IEnumerable<Appointment> list) =>
        list.OrderByDescending(a => a.CreatedAt).ToList();

    /// <summary>The appointment's day, or null when the text cannot be read (handy for sorting and filtering).</summary>
    public static DateTime? ScheduleDate(this Appointment a) =>
        a.TryGetSchedule(out var date, out _) ? date : null;

    /// <summary>True when the appointment starts exactly at that day and hour.</summary>
    public static bool IsAt(this Appointment a, DateTime start) =>
        a.TryGetSchedule(out var day, out var slot) && day.AddHours(int.Parse(slot.Substring(0, 2))) == start;

    /// <summary>True when the appointment is on the given day.</summary>
    public static bool IsOn(this Appointment a, DateTime day) =>
        a.ScheduleDate() == day.Date;
}
