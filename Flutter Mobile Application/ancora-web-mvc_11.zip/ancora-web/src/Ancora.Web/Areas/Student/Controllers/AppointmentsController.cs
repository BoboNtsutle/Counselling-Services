using Ancora.Web.Models;
using Ancora.Web.Services;
using Ancora.Web.Services.Supabase;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Student.Controllers;

/// <summary>The student's own appointments: current ones (with a cancel button) and the history. URL: /Student/Appointments</summary>
[Area("Student")]
[Authorize(Roles = Roles.Student)]
public class AppointmentsController : Controller
{
    private readonly ProfileService _profiles;

    public AppointmentsController(ProfileService profiles) => _profiles = profiles;

    public async Task<IActionResult> Index()
    {
        var all = await _profiles.GetMyAppointmentsAsync(User.GetUserId());
        var current = all
            .Where(a => a.Status == AppointmentStatus.Pending || a.Status == AppointmentStatus.Approved)
            .ToList();
        return View(current);
    }

    // Past and closed appointments: finished (Complete), turned down (Rejected) or cancelled.
    public async Task<IActionResult> History()
    {
        var all = await _profiles.GetMyAppointmentsAsync(User.GetUserId());
        var closed = all
            .Where(a => a.Status == AppointmentStatus.Complete || a.Status == AppointmentStatus.Rejected || a.Status == AppointmentStatus.Cancelled)
            .OrderByDescending(a => a.ScheduleDate())
            .ToList();
        return View(closed);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(Guid id)
    {
        try
        {
            // The service only changes the row if it belongs to this student, and checks that it really changed.
            await _profiles.CancelAppointmentAsync(id, User.GetUserId());
            TempData[Flash.Success] = "Appointment cancelled.";
        }
        catch (InvalidOperationException ex)
        {
            TempData[Flash.Error] = ex.Message;
        }
        return RedirectToAction(nameof(Index));
    }
}
