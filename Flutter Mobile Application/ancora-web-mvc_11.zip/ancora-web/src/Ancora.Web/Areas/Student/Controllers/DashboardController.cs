using System.Net;
using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services;
using Ancora.Web.Services.Supabase;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Student.Controllers;

/// <summary>
/// Student home page. URL: /Student
/// Shows the student's current appointments and the latest news the admin published.
/// Each part is loaded on its own, so one failing query can never block the whole page.
/// </summary>
[Area("Student")]
[Authorize(Roles = Roles.Student)]
public class DashboardController : Controller
{
    private readonly ProfileService _profiles;
    private readonly AnnouncementService _announcements;

    public DashboardController(ProfileService profiles, AnnouncementService announcements)
    {
        _profiles = profiles;
        _announcements = announcements;
    }

    public async Task<IActionResult> Index()
    {
        var userId = User.GetUserId();
        var model = new StudentDashboardViewModel();

        // 1. The student's own profile (for the greeting).
        var profile = await LoadAsync(() => _profiles.GetProfileAsync(userId), null);
        model.Profile = profile.Data;
        model.ProfileError = profile.Error;

        // 2. Current appointments = still waiting for approval, or approved. Soonest first.
        var mine = await LoadAsync(() => _profiles.GetMyAppointmentsAsync(userId), new List<Appointment>());
        model.AppointmentsError = mine.Error;
        model.Upcoming = mine.Data
            .Where(a => a.Status == AppointmentStatus.Pending || a.Status == AppointmentStatus.Approved)
            .OrderBy(a => a.ScheduleDate())
            .ThenBy(a => a.AppointmentTime)
            .ToList();
        model.Next = model.Upcoming.FirstOrDefault();
        model.PendingCount = model.Upcoming.Count(a => a.Status == AppointmentStatus.Pending);

        // 3. Latest news (the service already sorts newest first); show the latest three.
        var news = await LoadAsync(() => _announcements.GetAllAsync(), new List<Announcement>());
        model.NewsError = news.Error;
        model.News = news.Data.Take(3).ToList();
        model.NewNewsCount = news.Data.Count(n => n.CreatedAt > DateTimeOffset.UtcNow.AddDays(-7));

        return View(model);
    }

    /// <summary>
    /// Runs one query. If Supabase refuses it, return an empty result plus the reason.
    /// An expired login (401) is NOT caught here: SupabaseErrorFilter sends the user back to sign in.
    /// </summary>
    private static async Task<(T Data, string? Error)> LoadAsync<T>(Func<Task<T>> query, T empty)
    {
        try
        {
            return (await query(), null);
        }
        catch (SupabaseException ex) when (ex.StatusCode != HttpStatusCode.Unauthorized)
        {
            return (empty, ex.Message);
        }
        catch (HttpRequestException)
        {
            return (empty, "Could not reach Supabase. Check your internet connection.");
        }
    }
}
