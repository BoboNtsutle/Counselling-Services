using Ancora.Web.Models;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Psychologist.Controllers;

/// <summary>
/// Student records for a psychologist (read only). A psychologist only sees the students who have
/// an appointment with them. URL: /Psychologist/Students
/// Uses the same two pages as the admin (Views/Shared/StudentRecords*.cshtml).
/// </summary>
[Area("Psychologist")]
[Authorize(Roles = Roles.Psychologist)]
public class StudentsController : Controller
{
    private readonly PsychologistService _service;

    public StudentsController(PsychologistService service) => _service = service;

    // Search box: matches name, student number or email.
    public async Task<IActionResult> Index(string? q)
    {
        ViewBag.Query = q;
        var students = await _service.GetMyStudentsAsync(User.GetUserId(), q);
        return View("~/Views/Shared/StudentRecords.cshtml", students);
    }

    // One student's record (only the sessions with me). Not one of my students = not found.
    public async Task<IActionResult> Details(Guid id)
    {
        var record = await _service.GetMyStudentRecordAsync(User.GetUserId(), id);
        if (record == null) return NotFound();
        return View("~/Views/Shared/StudentRecord.cshtml", record);
    }
}
