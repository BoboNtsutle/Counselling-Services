using Ancora.Web.Models;
using Ancora.Web.Models.Admin;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Psychologist.Controllers;

/// <summary>
/// The psychologist's own calendar: which hours are booked and which are free, plus the days
/// they have switched off (for example "On leave"). URL: /Psychologist/Availability
/// </summary>
[Area("Psychologist")]
[Authorize(Roles = Roles.Psychologist)]
public class AvailabilityController : Controller
{
    private readonly PsychologistService _psychologists;
    private readonly ProfileService _profiles;
    private readonly TimeOffService _timeOff;

    public AvailabilityController(PsychologistService psychologists, ProfileService profiles, TimeOffService timeOff)
    {
        _psychologists = psychologists;
        _profiles = profiles;
        _timeOff = timeOff;
    }

    // Current month unless ?year=&month= are given. ?offDate= pre-fills the "switch off a day" form.
    public async Task<IActionResult> Index(int? year, int? month, string? offDate)
    {
        var today = DateTime.Today;
        var y = year ?? today.Year;
        var m = month ?? today.Month;
        if (m < 1 || m > 12 || y < 2000 || y > 2100) { y = today.Year; m = today.Month; }

        var me = await _profiles.GetProfileAsync(User.GetUserId());
        var mine = await _psychologists.GetMyAppointmentsAsync(User.GetUserId());
        var approved = mine.Where(a => a.Status == AppointmentStatus.Approved).ToList();   // only Approved blocks a slot

        var psychologists = me == null ? new List<Profile>() : new List<Profile> { me };
        var model = AvailabilityViewModel.ForMonth(y, m, psychologists, me?.Id, approved);
        model.SetDaysOff(await _timeOff.GetAsync(User.GetUserId()));

        ViewBag.OffDate = offDate;
        return View(model);
    }

    // Switch off a period: every working day from "fromDate" to "toDate" (the same day if toDate is empty),
    // with a reason such as "On leave".
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SwitchOff(DateTime? fromDate, DateTime? toDate, string? reason)
    {
        try
        {
            if (!fromDate.HasValue) throw new InvalidOperationException("Please choose the first day to switch off.");
            var from = fromDate.Value.Date;
            var to = (toDate ?? fromDate).Value.Date;

            var days = await _timeOff.AddRangeAsync(User.GetUserId(), from, to, reason);

            // Warn (but do not block) when students are already booked in that period.
            var mine = await _psychologists.GetMyAppointmentsAsync(User.GetUserId());
            var booked = mine.Count(a => a.Status == AppointmentStatus.Approved
                                         && a.ScheduleDate() >= from && a.ScheduleDate() <= to);

            var period = from == to ? $"{from:d MMM yyyy}" : $"{from:d MMM yyyy} to {to:d MMM yyyy}";
            TempData["FlashSuccess"] = booked == 0
                ? $"Switched off {period} ({days} working day(s))."
                : $"Switched off {period} ({days} working day(s)). You still have {booked} approved appointment(s) in that period: please reschedule them.";

            return RedirectToAction(nameof(Index), new { year = from.Year, month = from.Month });
        }
        catch (InvalidOperationException ex)
        {
            TempData["FlashError"] = ex.Message;
            return RedirectToAction(nameof(Index));
        }
    }

    // Switch a whole period back on (the ids are all the days of that period).
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> SwitchOn(List<Guid> ids)
    {
        await _timeOff.RemoveAsync(ids, User.GetUserId());
        TempData["FlashSuccess"] = "Those days are switched back on.";
        return RedirectToAction(nameof(Index));
    }
}
