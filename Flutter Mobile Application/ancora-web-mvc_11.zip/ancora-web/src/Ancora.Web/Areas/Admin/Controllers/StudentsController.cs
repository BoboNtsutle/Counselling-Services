using Ancora.Web.Models;
using Ancora.Web.Services;
using Ancora.Web.Services.Supabase;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>
/// Manage students: search, open a record, edit details. URL: /Admin/Students
/// The list and the record page are shared with the psychologist (Views/Shared/StudentRecords*.cshtml).
/// </summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin)]
public class StudentsController : Controller
{
    private readonly UserAdminService _service;

    public StudentsController(UserAdminService service) => _service = service;

    // Search box: matches name, student number or email. Empty search = all students.
    public async Task<IActionResult> Index(string? q)
    {
        ViewBag.Query = q;
        var students = await _service.SearchStudentsAsync(q);
        return View("~/Views/Shared/StudentRecords.cshtml", students);
    }

    // One student's record.
    public async Task<IActionResult> Details(Guid id)
    {
        var record = await _service.GetStudentRecordAsync(id);
        if (record == null) return NotFound();
        return View("~/Views/Shared/StudentRecord.cshtml", record);
    }

    // GET: the edit form.
    public async Task<IActionResult> Edit(Guid id)
    {
        var student = await _service.GetStudentAsync(id);
        if (student == null) return NotFound();
        return View(student);
    }

    // POST: save the changes, then show the record.
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Guid id, string displayName, string? studentNumber, string? course, string? phoneNumber)
    {
        if (string.IsNullOrWhiteSpace(displayName))
        {
            TempData[Flash.Error] = "The name cannot be empty.";
            return RedirectToAction(nameof(Edit), new { id });
        }

        await _service.UpdateStudentAsync(id, displayName, studentNumber ?? "", course ?? "", phoneNumber ?? "");
        TempData[Flash.Success] = "Student details saved.";
        return RedirectToAction(nameof(Details), new { id });
    }
}
