using Ancora.Web.Models;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>
/// Tells the admin pages whether new appointment requests have arrived.
/// The small script wwwroot/js/admin-notifications.js asks this every 30 seconds. URL: /Admin/Notifications/Latest
/// </summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin)]
public class NotificationsController : Controller
{
    private readonly AppointmentAdminService _appointments;

    public NotificationsController(AppointmentAdminService appointments) => _appointments = appointments;

    [HttpGet]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> Latest()
    {
        // Requests still waiting for an answer, newest first.
        var pending = await _appointments.GetAllAsync(AppointmentStatus.Pending);
        var newest = pending.FirstOrDefault();

        return Json(new
        {
            pending = pending.Count,
            newest = newest == null ? null : new
            {
                id = newest.Id,
                student = newest.StudentName,
                date = newest.AppointmentDate,
                time = newest.AppointmentTime,
                urgency = newest.Urgency,
                url = Url.Action("Details", "Appointments", new { area = "Admin", id = newest.Id })
            }
        });
    }
}
