using Ancora.Web.Models;
using Ancora.Web.Services.Supabase;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>Admin settings: change your own password. URL: /Admin/Settings</summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin)]
public class SettingsController : Controller
{
    private readonly SupabaseAuthService _auth;
    private readonly SupabaseSessionStore _session;

    public SettingsController(SupabaseAuthService auth, SupabaseSessionStore session)
    {
        _auth = auth;
        _session = session;
    }

    public IActionResult Index() => View();

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> ChangePassword(string? newPassword, string? confirmPassword)
    {
        if (string.IsNullOrEmpty(newPassword) || newPassword.Length < 6)
        {
            TempData[Flash.Error] = "The new password must be at least 6 characters.";
            return RedirectToAction(nameof(Index));
        }
        if (newPassword != confirmPassword)
        {
            TempData[Flash.Error] = "The two passwords do not match.";
            return RedirectToAction(nameof(Index));
        }

        // The session store gives a valid token (it refreshes an old one for us).
        var token = await _session.GetAccessTokenAsync();
        if (token == null) return RedirectToAction("Login", "Account", new { area = "" });

        await _auth.UpdatePasswordAsync(token, newPassword);
        TempData[Flash.Success] = "Password changed.";
        return RedirectToAction(nameof(Index));
    }
}
