using Ancora.Web.Models;
using Ancora.Web.Models.Admin;
using Ancora.Web.Services;
using Ancora.Web.Services.Supabase;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>Admin: monthly calendar showing when a psychologist is free or booked. URL: /Admin/Availability</summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin)]
public class AvailabilityController : Controller
{
    private readonly AppointmentAdminService _appointments;
    private readonly TimeOffService _timeOff;

    public AvailabilityController(AppointmentAdminService appointments, TimeOffService timeOff)
    {
        _appointments = appointments;
        _timeOff = timeOff;
    }

    // Current month and first psychologist unless ?year=&month=&psychologistId= are given.
    public async Task<IActionResult> Index(int? year, int? month, Guid? psychologistId)
    {
        var today = DateTime.Today;
        var y = year ?? today.Year;
        var m = month ?? today.Month;
        if (m < 1 || m > 12 || y < 2000 || y > 2100) { y = today.Year; m = today.Month; }

        var psychologists = await _appointments.GetPsychologistsAsync();
        var approved = await _appointments.GetAllAsync(AppointmentStatus.Approved);   // only Approved blocks a slot

        var model = AvailabilityViewModel.ForMonth(y, m, psychologists, psychologistId, approved);
        // Show the days this psychologist has switched off (with the reason) on the calendar.
        if (model.Selected != null) model.SetDaysOff(await _timeOff.GetAsync(model.Selected.Id));
        return View(model);
    }

    // The admin clicked a FREE time: show the pending requests that could go there.
    public async Task<IActionResult> Slot(Guid psychologistId, string date, string time)
    {
        try
        {
            var start = AppointmentAdminService.ReadSlot(date, time);

            var psychologist = (await _appointments.GetPsychologistsAsync()).FirstOrDefault(p => p.Id == psychologistId);
            if (psychologist == null) return NotFound();

            var off = await _timeOff.GetDayOffAsync(psychologistId, date);
            if (off != null)
                throw new InvalidOperationException($"{psychologist.DisplayName} is off on {date} ({off.Reason}).");

            if (await _appointments.IsSlotTakenAsync(psychologistId, start))
                throw new InvalidOperationException("That time is already booked.");

            var pending = await _appointments.GetAllAsync(AppointmentStatus.Pending);
            // Requests that asked for exactly this day and hour come first, then the rest, newest request first.
            var sorted = pending
                .OrderByDescending(a => a.IsAt(start))
                .ThenByDescending(a => a.CreatedAt)
                .ToList();

            ViewBag.Psychologist = psychologist;
            ViewBag.Start = start;
            ViewBag.Date = date;
            ViewBag.Time = time;
            return View(sorted);
        }
        catch (InvalidOperationException ex)
        {
            TempData[Flash.Error] = ex.Message;
            return RedirectToAction(nameof(Index), new { psychologistId });
        }
    }

    // Put the chosen pending request into that free time and approve it.
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Book(Guid appointmentId, Guid psychologistId, string date, string time)
    {
        try
        {
            await _appointments.BookIntoSlotAsync(appointmentId, psychologistId, date, time);
            TempData[Flash.Success] = $"Booked for {date} at {time} and approved.";
            var day = DateTime.ParseExact(date, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
            return RedirectToAction(nameof(Index), new { year = day.Year, month = day.Month, psychologistId });
        }
        catch (InvalidOperationException ex)
        {
            TempData[Flash.Error] = ex.Message;
            return RedirectToAction(nameof(Slot), new { psychologistId, date, time });
        }
    }
}
