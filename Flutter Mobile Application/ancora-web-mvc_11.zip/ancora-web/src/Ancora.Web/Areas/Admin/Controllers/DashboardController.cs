using Ancora.Web.Models;
using Ancora.Web.Models.ViewModels;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>Admin home page: totals, upcoming appointments and the latest announcement. URL: /Admin</summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin)]
public class DashboardController : Controller
{
    private readonly UserAdminService _users;
    private readonly AppointmentAdminService _appointments;
    private readonly AnnouncementService _announcements;

    public DashboardController(UserAdminService users, AppointmentAdminService appointments, AnnouncementService announcements)
    {
        _users = users;
        _appointments = appointments;
        _announcements = announcements;
    }

    public async Task<IActionResult> Index()
    {
        var all = await _appointments.GetAllAsync();

        // "This week" = Monday to Sunday of the current week.
        var today = DateTime.Today;
        var weekStart = today.AddDays(-(((int)today.DayOfWeek + 6) % 7));
        var weekEnd = weekStart.AddDays(7);

        var model = new AdminDashboardViewModel
        {
            TotalStudents = await _users.CountStudentsAsync(),
            Pending = all.Count(a => a.Status == AppointmentStatus.Pending),
            ThisWeek = all.Count(a => IsOpen(a) && a.ScheduleDate() >= weekStart && a.ScheduleDate() < weekEnd),
            Upcoming = all
                .Where(a => IsOpen(a) && a.ScheduleDate() >= today)
                .OrderBy(a => a.ScheduleDate()).ThenBy(a => a.AppointmentTime)
                .Take(5)
                .ToList(),
            LatestAnnouncement = (await _announcements.GetAllAsync()).FirstOrDefault()
        };
        return View(model);
    }

    // "Open" = still going to happen (waiting for approval, or approved).
    private static bool IsOpen(Appointment a) =>
        a.Status == AppointmentStatus.Pending || a.Status == AppointmentStatus.Approved;
}
