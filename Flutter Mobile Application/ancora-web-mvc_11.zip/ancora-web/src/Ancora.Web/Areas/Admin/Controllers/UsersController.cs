using Ancora.Web.Models;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>MODULE 3 — Users, role requests &amp; student records (FR-06, FR-07, FR-10). URL: /Admin/Users</summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin)]
public class UsersController : Controller
{
    private readonly UserAdminService _service;

    public UsersController(UserAdminService service) => _service = service;

    // DONE (starter): pending role requests + list of psychologists.
    public async Task<IActionResult> Index()
    {
        ViewBag.Psychologists = await _service.GetByRoleAsync(Roles.Psychologist);
        var pending = await _service.GetPendingRoleRequestsAsync();
        return View(pending);
    }

    // Approve a staff access request (psychologist, or admin if that is what they asked for).
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Approve(Guid id, string role)
    {
        try
        {
            await _service.ApproveRoleRequestAsync(id, role);
            TempData["FlashSuccess"] = "Request approved. They get the new role the next time they sign in.";
        }
        catch (InvalidOperationException ex) { TempData["FlashError"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }

    // Reject a staff access request (the person stays a student).
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Reject(Guid id)
    {
        try
        {
            await _service.RejectRoleRequestAsync(id);
            TempData["FlashSuccess"] = "Request rejected.";
        }
        catch (InvalidOperationException ex) { TempData["FlashError"] = ex.Message; }
        return RedirectToAction(nameof(Index));
    }
}
