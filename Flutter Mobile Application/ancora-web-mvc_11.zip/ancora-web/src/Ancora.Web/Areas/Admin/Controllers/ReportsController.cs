using Ancora.Web.Models;
using Ancora.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ancora.Web.Areas.Admin.Controllers;

/// <summary>Reports and statistics: plain counts for an optional date range (FR-11). URL: /Admin/Reports</summary>
[Area("Admin")]
[Authorize(Roles = Roles.Admin + "," + Roles.Psychologist)]
public class ReportsController : Controller
{
    private readonly ReportService _service;

    public ReportsController(ReportService service) => _service = service;

    public async Task<IActionResult> Index(DateTime? from, DateTime? to)
    {
        // Remember the chosen dates so the filter boxes stay filled in.
        ViewBag.From = from?.ToString("yyyy-MM-dd") ?? "";
        ViewBag.To = to?.ToString("yyyy-MM-dd") ?? "";
        return View(await _service.GetStatisticsAsync(from, to));
    }

    // The same numbers as JSON (kept from the earlier version).
    [HttpGet]
    public async Task<IActionResult> StatisticsJson(DateTime? from, DateTime? to) =>
        Json(await _service.GetStatisticsAsync(from, to));
}
