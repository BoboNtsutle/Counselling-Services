-- =====================================================================
--  Ancora — "switch off days" (psychologist days off / leave)
--  Run in Supabase > SQL Editor. Safe to run again.
--
--  One row per switched-off working day. When a psychologist switches off
--  "2 Nov to 6 Nov", the web app saves five rows (one per weekday) with the same reason.
--  The web app joins them back into one period when it shows them.
-- =====================================================================

-- Helper used by the policies (the same one schema.sql creates; harmless to create again).
-- It needs the "profiles" table to exist, so run schema.sql first on a new project.
create or replace function public.current_user_role()
returns text
language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

-- ---------- The table ----------
create table if not exists public.psychologist_time_off (
  id              uuid primary key default gen_random_uuid(),
  psychologist_id uuid        not null references auth.users (id) on delete cascade,
  off_date        date        not null,                    -- the day that is switched off
  reason          text        not null default '',         -- e.g. "On leave"
  created_at      timestamptz not null default now(),
  unique (psychologist_id, off_date)                       -- a day can only be switched off once
);

create index if not exists time_off_psychologist_idx
  on public.psychologist_time_off (psychologist_id, off_date);

-- ---------- Who can do what ----------
alter table public.psychologist_time_off enable row level security;
grant select, insert, delete on public.psychologist_time_off to authenticated;

-- A psychologist sees, adds and removes THEIR OWN days off.
drop policy if exists "time off psychologist read own" on public.psychologist_time_off;
create policy "time off psychologist read own" on public.psychologist_time_off
  for select to authenticated using (psychologist_id = auth.uid());

drop policy if exists "time off psychologist insert own" on public.psychologist_time_off;
create policy "time off psychologist insert own" on public.psychologist_time_off
  for insert to authenticated
  with check (psychologist_id = auth.uid() and public.current_user_role() = 'psychologist');

drop policy if exists "time off psychologist delete own" on public.psychologist_time_off;
create policy "time off psychologist delete own" on public.psychologist_time_off
  for delete to authenticated using (psychologist_id = auth.uid());

-- Admins can see everyone's days off (the availability calendar and the booking checks need this).
drop policy if exists "time off admin read all" on public.psychologist_time_off;
create policy "time off admin read all" on public.psychologist_time_off
  for select to authenticated using (public.current_user_role() = 'admin');

drop policy if exists "time off admin delete" on public.psychologist_time_off;
create policy "time off admin delete" on public.psychologist_time_off
  for delete to authenticated using (public.current_user_role() = 'admin');
