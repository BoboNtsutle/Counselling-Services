-- =====================================================================
--  Ancora — update for databases that ALREADY ran supabase/schema.sql
--  Run ONCE in Supabase > SQL Editor (safe to run again).
--
--  1. New appointment status "Cancelled" (a student cancelling is no longer "Rejected").
--  2. Students may set Cancelled; the guard rule is replaced to allow it.
--  3. New table psychologist_time_off: days a psychologist has switched off, with a reason.
--
--  Starting from an empty project? Run supabase/schema.sql instead; it includes all of this.
-- =====================================================================

-- Allowed statuses. Missed = date passed and never marked Complete. Cancelled = the student cancelled.
-- Replaces any older status check.
do $$
declare c record;
begin
  for c in
    select conname from pg_constraint
    where conrelid = 'public.appointments'::regclass
      and contype = 'c'
      and pg_get_constraintdef(oid) ilike '%Pending%'
  loop
    execute format('alter table public.appointments drop constraint %I', c.conname);
  end loop;

  alter table public.appointments
    add constraint appointments_status_check
    check (status in ('Pending', 'Approved', 'Rejected', 'Complete', 'Missed', 'Cancelled'));
end $$;

-- Trigger 2: who may change what when an appointment is UPDATED.
--   admin        : anything
--   psychologist : status (Approved / Rejected / Complete / Missed) and the date/time of THEIR appointments
--   student      : only cancel (Cancelled) or let it become Missed
create or replace function public.guard_appointment_update()
returns trigger
language plpgsql security definer set search_path = public
as $$
declare r text := coalesce(public.current_user_role(), '');
begin
  -- SQL editor / server jobs have no signed-in user; admins may do anything.
  if auth.uid() is null or r = 'admin' then return new; end if;

  if new.student_id <> old.student_id or new.psychologist_id is distinct from old.psychologist_id then
    raise exception 'Only an admin can change who an appointment is for or who it is assigned to.';
  end if;

  if r = 'psychologist' then
    if new.status <> old.status and new.status not in ('Approved', 'Rejected', 'Complete', 'Missed') then
      raise exception 'A psychologist cannot set the status to %.', new.status;
    end if;
    if (new.reason, new.mood, new.urgency, new.student_name, new.student_number, new.course)
       is distinct from (old.reason, old.mood, old.urgency, old.student_name, old.student_number, old.course) then
      raise exception 'Only the status and the date/time of an appointment can be changed.';
    end if;
  else
    if new.status <> old.status and new.status not in ('Rejected', 'Cancelled', 'Missed') then
      raise exception 'Students can only cancel an appointment.';
    end if;
    if (new.appointment_date, new.appointment_time, new.reason, new.mood, new.urgency,
        new.student_name, new.student_number, new.course)
       is distinct from (old.appointment_date, old.appointment_time, old.reason, old.mood, old.urgency,
        old.student_name, old.student_number, old.course) then
      raise exception 'Students can only cancel an appointment.';
    end if;
  end if;

  return new;
end $$;

-- (the trigger already points at this function, nothing else to do)

-- =====================================================================
-- 6) DAYS OFF  (a psychologist switches a day off, with a reason such as "On leave")
-- =====================================================================
create table if not exists public.psychologist_time_off (
  id              uuid primary key default gen_random_uuid(),
  psychologist_id uuid        not null references auth.users (id) on delete cascade,
  off_date        date        not null,
  reason          text        not null default '',
  created_at      timestamptz not null default now(),
  unique (psychologist_id, off_date)           -- a day can only be switched off once
);

create index if not exists time_off_psychologist_idx on public.psychologist_time_off (psychologist_id, off_date);

alter table public.psychologist_time_off enable row level security;
grant select, insert, delete on public.psychologist_time_off to authenticated;

-- A psychologist sees, adds and removes THEIR OWN days off.
drop policy if exists "time off psychologist read own" on public.psychologist_time_off;
create policy "time off psychologist read own" on public.psychologist_time_off
  for select to authenticated using (psychologist_id = auth.uid());

drop policy if exists "time off psychologist insert own" on public.psychologist_time_off;
create policy "time off psychologist insert own" on public.psychologist_time_off
  for insert to authenticated
  with check (psychologist_id = auth.uid() and public.current_user_role() = 'psychologist');

drop policy if exists "time off psychologist delete own" on public.psychologist_time_off;
create policy "time off psychologist delete own" on public.psychologist_time_off
  for delete to authenticated using (psychologist_id = auth.uid());

-- Admins can see everyone's days off (the availability calendar and the booking checks need this).
drop policy if exists "time off admin read all" on public.psychologist_time_off;
create policy "time off admin read all" on public.psychologist_time_off
  for select to authenticated using (public.current_user_role() = 'admin');

drop policy if exists "time off admin delete" on public.psychologist_time_off;
create policy "time off admin delete" on public.psychologist_time_off
  for delete to authenticated using (public.current_user_role() = 'admin');


