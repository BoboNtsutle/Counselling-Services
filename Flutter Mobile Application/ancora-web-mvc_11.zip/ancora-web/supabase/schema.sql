-- =====================================================================
--  Ancora Counselling Services — COMPLETE database setup
--  Run this ONCE in Supabase > SQL Editor (it is safe to run again).
--
--  Fixes the message:  "Supabase tables are missing. Run supabase/schema.sql"
--
--  Creates everything the web app (and the Flutter app) read and write:
--    1. profiles        – one row per person, with their role
--    2. appointments    – session requests and bookings
--    3. clinical_notes  – private session notes
--    4. announcements   – news for students (with an optional "remove after" date)
--    5. psychologist_time_off – days a psychologist has switched off (leave), with a reason
--    6. storage bucket  – "announcement-images" for announcement pictures
--
--  This file was rebuilt from the C# models and from every query the web app makes,
--  because the original schema.sql was not in the project. If your Supabase project
--  already has these tables, compare before running (see the notes at the bottom).
-- =====================================================================


-- =====================================================================
-- 1) PROFILES
-- =====================================================================
create table if not exists public.profiles (
  -- Same id as the Supabase Auth user (auth.users.id)
  id                  uuid primary key references auth.users (id) on delete cascade,
  email               text        not null default '',
  display_name        text        not null default '',

  -- What the person is allowed to do. The web app copies this into the login cookie.
  role                text        not null default 'student'
                        check (role in ('student', 'psychologist', 'admin')),

  -- Someone asking for staff access. Does NOT grant anything until an admin approves.
  requested_role      text        not null default 'student'
                        check (requested_role in ('student', 'psychologist', 'admin')),
  role_request_status text        not null default 'none'
                        check (role_request_status in ('none', 'pending', 'approved', 'rejected')),

  student_number      text        not null default '',
  course              text        not null default '',
  phone_number        text        not null default '',
  bio                 text        not null default '',   -- psychologists use it as "Specialisation"
  created_at          timestamptz not null default now()
);

-- If the table already existed without some columns, add them.
alter table public.profiles add column if not exists email               text        not null default '';
alter table public.profiles add column if not exists display_name        text        not null default '';
alter table public.profiles add column if not exists role                text        not null default 'student';
alter table public.profiles add column if not exists requested_role      text        not null default 'student';
alter table public.profiles add column if not exists role_request_status text        not null default 'none';
alter table public.profiles add column if not exists student_number      text        not null default '';
alter table public.profiles add column if not exists course              text        not null default '';
alter table public.profiles add column if not exists phone_number        text        not null default '';
alter table public.profiles add column if not exists bio                 text        not null default '';
alter table public.profiles add column if not exists created_at          timestamptz not null default now();

create index if not exists profiles_role_idx        on public.profiles (role);
create index if not exists profiles_role_status_idx on public.profiles (role_request_status);
create index if not exists profiles_name_idx        on public.profiles (display_name);

alter table public.profiles enable row level security;

-- Helper: the caller's role. SECURITY DEFINER avoids policies calling themselves forever.
create or replace function public.current_user_role()
returns text
language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;


-- =====================================================================
-- 2) APPOINTMENTS
-- =====================================================================
-- appointment_date / appointment_time are TEXT on purpose: the web app saves "2026-10-12" and "09:00",
-- the Flutter app may save "Fri, Oct 9" and "9:00 AM". The web app understands both.
create table if not exists public.appointments (
  id                uuid primary key default gen_random_uuid(),
  student_id        uuid        not null references auth.users (id) on delete cascade,
  psychologist_id   uuid                 references auth.users (id) on delete set null,
  psychologist_name text        not null default '',   -- filled in by a trigger below
  student_name      text        not null default '',
  student_number    text        not null default '',
  course            text        not null default '',
  appointment_date  text        not null default '',
  appointment_time  text        not null default '',
  reason            text        not null default '',
  mood              text        not null default '',
  urgency           text        not null default 'Routine',   -- Routine / Soon / Urgent
  status            text        not null default 'Pending',
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

alter table public.appointments add column if not exists psychologist_id   uuid references auth.users (id) on delete set null;
alter table public.appointments add column if not exists psychologist_name text        not null default '';
alter table public.appointments add column if not exists student_name      text        not null default '';
alter table public.appointments add column if not exists student_number    text        not null default '';
alter table public.appointments add column if not exists course            text        not null default '';
alter table public.appointments add column if not exists appointment_date  text        not null default '';
alter table public.appointments add column if not exists appointment_time  text        not null default '';
alter table public.appointments add column if not exists reason            text        not null default '';
alter table public.appointments add column if not exists mood              text        not null default '';
alter table public.appointments add column if not exists urgency           text        not null default 'Routine';
alter table public.appointments add column if not exists status            text        not null default 'Pending';
alter table public.appointments add column if not exists updated_at        timestamptz not null default now();

-- Allowed statuses. Missed = date passed and never marked Complete. Cancelled = the student cancelled.
-- Replaces any older status check.
do $$
declare c record;
begin
  for c in
    select conname from pg_constraint
    where conrelid = 'public.appointments'::regclass
      and contype = 'c'
      and pg_get_constraintdef(oid) ilike '%Pending%'
  loop
    execute format('alter table public.appointments drop constraint %I', c.conname);
  end loop;

  alter table public.appointments
    add constraint appointments_status_check
    check (status in ('Pending', 'Approved', 'Rejected', 'Complete', 'Missed', 'Cancelled'));
end $$;

create index if not exists appointments_student_idx      on public.appointments (student_id);
create index if not exists appointments_psychologist_idx on public.appointments (psychologist_id);
create index if not exists appointments_status_idx       on public.appointments (status);
create index if not exists appointments_created_idx      on public.appointments (created_at desc);

alter table public.appointments enable row level security;

-- Trigger 1: tidy-up on every insert/update.
--   * a student's new request always starts as Pending and unassigned
--   * psychologist_name is copied from the psychologist's profile
--   * updated_at is refreshed
create or replace function public.appointments_fill()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  if tg_op = 'INSERT' and auth.uid() is not null and coalesce(public.current_user_role(), 'student') <> 'admin' then
    new.status := 'Pending';
    new.psychologist_id := null;
  end if;

  if new.psychologist_id is null then
    new.psychologist_name := '';
  elsif tg_op = 'INSERT' or new.psychologist_id is distinct from old.psychologist_id then
    select coalesce(display_name, '') into new.psychologist_name from public.profiles where id = new.psychologist_id;
  end if;

  new.updated_at := now();
  return new;
end $$;

drop trigger if exists appointments_fill on public.appointments;
create trigger appointments_fill
  before insert or update on public.appointments
  for each row execute function public.appointments_fill();

-- Trigger 2: who may change what when an appointment is UPDATED.
--   admin        : anything
--   psychologist : status (Approved / Rejected / Complete / Missed) and the date/time of THEIR appointments
--   student      : only cancel (Cancelled) or let it become Missed
create or replace function public.guard_appointment_update()
returns trigger
language plpgsql security definer set search_path = public
as $$
declare r text := coalesce(public.current_user_role(), '');
begin
  -- SQL editor / server jobs have no signed-in user; admins may do anything.
  if auth.uid() is null or r = 'admin' then return new; end if;

  if new.student_id <> old.student_id or new.psychologist_id is distinct from old.psychologist_id then
    raise exception 'Only an admin can change who an appointment is for or who it is assigned to.';
  end if;

  if r = 'psychologist' then
    if new.status <> old.status and new.status not in ('Approved', 'Rejected', 'Complete', 'Missed') then
      raise exception 'A psychologist cannot set the status to %.', new.status;
    end if;
    if (new.reason, new.mood, new.urgency, new.student_name, new.student_number, new.course)
       is distinct from (old.reason, old.mood, old.urgency, old.student_name, old.student_number, old.course) then
      raise exception 'Only the status and the date/time of an appointment can be changed.';
    end if;
  else
    if new.status <> old.status and new.status not in ('Rejected', 'Cancelled', 'Missed') then
      raise exception 'Students can only cancel an appointment.';
    end if;
    if (new.appointment_date, new.appointment_time, new.reason, new.mood, new.urgency,
        new.student_name, new.student_number, new.course)
       is distinct from (old.appointment_date, old.appointment_time, old.reason, old.mood, old.urgency,
        old.student_name, old.student_number, old.course) then
      raise exception 'Students can only cancel an appointment.';
    end if;
  end if;

  return new;
end $$;

drop trigger if exists appointments_guard on public.appointments;
create trigger appointments_guard
  before update on public.appointments
  for each row execute function public.guard_appointment_update();

grant select, insert, update, delete on public.appointments to authenticated;

-- Who can SEE appointments
drop policy if exists "appointments student read own" on public.appointments;
create policy "appointments student read own" on public.appointments
  for select to authenticated using (student_id = auth.uid());

drop policy if exists "appointments psychologist read assigned" on public.appointments;
create policy "appointments psychologist read assigned" on public.appointments
  for select to authenticated using (psychologist_id = auth.uid());

drop policy if exists "appointments admin read all" on public.appointments;
create policy "appointments admin read all" on public.appointments
  for select to authenticated using (public.current_user_role() = 'admin');

-- Who can CREATE one: a person, for themselves.
drop policy if exists "appointments insert own" on public.appointments;
create policy "appointments insert own" on public.appointments
  for insert to authenticated with check (student_id = auth.uid());

-- Who can CHANGE one (the guard trigger above narrows down WHAT they may change)
drop policy if exists "appointments student update own" on public.appointments;
create policy "appointments student update own" on public.appointments
  for update to authenticated using (student_id = auth.uid()) with check (student_id = auth.uid());

drop policy if exists "appointments psychologist update assigned" on public.appointments;
create policy "appointments psychologist update assigned" on public.appointments
  for update to authenticated using (psychologist_id = auth.uid()) with check (psychologist_id = auth.uid());

drop policy if exists "appointments admin update" on public.appointments;
create policy "appointments admin update" on public.appointments
  for update to authenticated
  using (public.current_user_role() = 'admin') with check (public.current_user_role() = 'admin');

drop policy if exists "appointments admin delete" on public.appointments;
create policy "appointments admin delete" on public.appointments
  for delete to authenticated using (public.current_user_role() = 'admin');


-- =====================================================================
-- 1b) PROFILES: policies and safety trigger
--     (after appointments, because one policy looks at appointments)
-- =====================================================================
grant select, insert, update on public.profiles to authenticated;

-- ---- EVERYONE: read and write their OWN profile ----
drop policy if exists "profiles read own" on public.profiles;
create policy "profiles read own" on public.profiles
  for select to authenticated using (id = auth.uid());

drop policy if exists "profiles insert own" on public.profiles;
create policy "profiles insert own" on public.profiles
  for insert to authenticated with check (id = auth.uid());

drop policy if exists "profiles update own" on public.profiles;
create policy "profiles update own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- ---- Admins: read and edit every profile ----
drop policy if exists "profiles admin read all" on public.profiles;
create policy "profiles admin read all" on public.profiles
  for select to authenticated using (public.current_user_role() = 'admin');

drop policy if exists "profiles admin update" on public.profiles;
create policy "profiles admin update" on public.profiles
  for update to authenticated
  using (public.current_user_role() = 'admin') with check (public.current_user_role() = 'admin');

-- ---- Psychologists: read the students who booked with them ----
drop policy if exists "profiles psychologist read own students" on public.profiles;
create policy "profiles psychologist read own students" on public.profiles
  for select to authenticated using (
    public.current_user_role() = 'psychologist'
    and exists (
      select 1 from public.appointments a
      where a.student_id = profiles.id and a.psychologist_id = auth.uid()
    )
  );

-- ---- Students: see the psychologists (the booking page lists them) ----
drop policy if exists "profiles read psychologists" on public.profiles;
create policy "profiles read psychologists" on public.profiles
  for select to authenticated using (role = 'psychologist');

-- Safety: only an admin may change a role. Without this, a student could call the API
-- directly and make themselves an admin.
create or replace function public.guard_profile_write()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is not null and coalesce(public.current_user_role(), 'student') <> 'admin' then
    if tg_op = 'INSERT' then
      new.role := 'student';                       -- new accounts always start as students
      new.role_request_status :=
        case when new.requested_role = 'student' then 'none' else 'pending' end;
    elsif tg_op = 'UPDATE' then
      new.role := old.role;                        -- only an admin may change these
      new.requested_role := old.requested_role;
      new.role_request_status := old.role_request_status;
    end if;
  end if;
  return new;
end $$;

drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard
  before insert or update on public.profiles
  for each row execute function public.guard_profile_write();


-- =====================================================================
-- 3) CLINICAL NOTES  (private: only the assigned psychologist and admins)
-- =====================================================================
create table if not exists public.clinical_notes (
  id             uuid primary key default gen_random_uuid(),
  appointment_id uuid not null unique references public.appointments (id) on delete cascade,  -- one note per appointment
  notes          text not null default '',
  updated_at     timestamptz not null default now()
);

alter table public.clinical_notes enable row level security;
grant select, insert, update on public.clinical_notes to authenticated;

drop policy if exists "notes staff read" on public.clinical_notes;
create policy "notes staff read" on public.clinical_notes
  for select to authenticated using (
    public.current_user_role() = 'admin'
    or exists (select 1 from public.appointments a
               where a.id = clinical_notes.appointment_id and a.psychologist_id = auth.uid())
  );

drop policy if exists "notes staff insert" on public.clinical_notes;
create policy "notes staff insert" on public.clinical_notes
  for insert to authenticated with check (
    public.current_user_role() = 'admin'
    or exists (select 1 from public.appointments a
               where a.id = clinical_notes.appointment_id and a.psychologist_id = auth.uid())
  );

drop policy if exists "notes staff update" on public.clinical_notes;
create policy "notes staff update" on public.clinical_notes
  for update to authenticated
  using (
    public.current_user_role() = 'admin'
    or exists (select 1 from public.appointments a
               where a.id = clinical_notes.appointment_id and a.psychologist_id = auth.uid())
  )
  with check (
    public.current_user_role() = 'admin'
    or exists (select 1 from public.appointments a
               where a.id = clinical_notes.appointment_id and a.psychologist_id = auth.uid())
  );


-- =====================================================================
-- 4) ANNOUNCEMENTS  (admin publishes, everyone reads)
-- =====================================================================
create table if not exists public.announcements (
  id         uuid primary key default gen_random_uuid(),
  title      text        not null,
  message    text        not null default '',
  image_url  text,
  expires_at timestamptz,                      -- optional: hidden and deleted after this moment
  created_at timestamptz not null default now()
);

alter table public.announcements add column if not exists image_url  text;
alter table public.announcements add column if not exists expires_at timestamptz;
create index if not exists announcements_created_idx on public.announcements (created_at desc);
create index if not exists announcements_expires_idx on public.announcements (expires_at);

alter table public.announcements enable row level security;
grant select, insert, update, delete on public.announcements to authenticated;

-- Everyone signed in sees announcements that have not expired (the Flutter app too).
drop policy if exists "announcements read live" on public.announcements;
create policy "announcements read live" on public.announcements
  for select to authenticated using (expires_at is null or expires_at > now());

-- Admins see all of them (including expired ones, so they can be cleaned up) and manage them.
drop policy if exists "announcements admin read all" on public.announcements;
create policy "announcements admin read all" on public.announcements
  for select to authenticated using (public.current_user_role() = 'admin');

drop policy if exists "announcements admin insert" on public.announcements;
create policy "announcements admin insert" on public.announcements
  for insert to authenticated with check (public.current_user_role() = 'admin');

drop policy if exists "announcements admin update" on public.announcements;
create policy "announcements admin update" on public.announcements
  for update to authenticated
  using (public.current_user_role() = 'admin') with check (public.current_user_role() = 'admin');

drop policy if exists "announcements admin delete" on public.announcements;
create policy "announcements admin delete" on public.announcements
  for delete to authenticated using (public.current_user_role() = 'admin');


-- =====================================================================
-- 5) DAYS OFF  (a psychologist switches a day off, with a reason such as "On leave")
-- =====================================================================
create table if not exists public.psychologist_time_off (
  id              uuid primary key default gen_random_uuid(),
  psychologist_id uuid        not null references auth.users (id) on delete cascade,
  off_date        date        not null,
  reason          text        not null default '',
  created_at      timestamptz not null default now(),
  unique (psychologist_id, off_date)           -- a day can only be switched off once
);

create index if not exists time_off_psychologist_idx on public.psychologist_time_off (psychologist_id, off_date);

alter table public.psychologist_time_off enable row level security;
grant select, insert, delete on public.psychologist_time_off to authenticated;

-- A psychologist sees, adds and removes THEIR OWN days off.
drop policy if exists "time off psychologist read own" on public.psychologist_time_off;
create policy "time off psychologist read own" on public.psychologist_time_off
  for select to authenticated using (psychologist_id = auth.uid());

drop policy if exists "time off psychologist insert own" on public.psychologist_time_off;
create policy "time off psychologist insert own" on public.psychologist_time_off
  for insert to authenticated
  with check (psychologist_id = auth.uid() and public.current_user_role() = 'psychologist');

drop policy if exists "time off psychologist delete own" on public.psychologist_time_off;
create policy "time off psychologist delete own" on public.psychologist_time_off
  for delete to authenticated using (psychologist_id = auth.uid());

-- Admins can see everyone's days off (the availability calendar and the booking checks need this).
drop policy if exists "time off admin read all" on public.psychologist_time_off;
create policy "time off admin read all" on public.psychologist_time_off
  for select to authenticated using (public.current_user_role() = 'admin');

drop policy if exists "time off admin delete" on public.psychologist_time_off;
create policy "time off admin delete" on public.psychologist_time_off
  for delete to authenticated using (public.current_user_role() = 'admin');


-- =====================================================================
-- 6) STORAGE: pictures for announcements (8 MB, images only, public to view)
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('announcement-images', 'announcement-images', true, 8388608,
        array['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- Only admins may upload, and only into a folder named after their own user id
-- (the web app saves to "<admin id>/<file>").
drop policy if exists "announcement images admin upload" on storage.objects;
create policy "announcement images admin upload" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'announcement-images'
    and public.current_user_role() = 'admin'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "announcement images admin delete" on storage.objects;
create policy "announcement images admin delete" on storage.objects
  for delete to authenticated using (
    bucket_id = 'announcement-images' and public.current_user_role() = 'admin'
  );


-- =====================================================================
-- AFTER RUNNING
-- =====================================================================
-- 1) Register in the app, then make yourself the first admin by running (use YOUR email):
--
--      update public.profiles
--         set role = 'admin', requested_role = 'admin', role_request_status = 'approved'
--       where email = 'you@example.com';
--
--    (This works in the SQL editor because the safety trigger only blocks signed-in app users.)
--    Then sign out and back in so the new role is picked up.
--
-- 2) Optional hourly clean-up inside the database (Database > Extensions > enable pg_cron):
--
--      select cron.schedule('ancora-expired', '10 * * * *',
--        $$ delete from public.announcements where expires_at is not null and expires_at < now() $$);
--
-- 3) If your project ALREADY had these tables (for example made by the Flutter app), the
--    "create table if not exists" lines keep your data. Drop any old policies on them first,
--    because several policies on one table combine with OR and an old, looser one would still apply.
