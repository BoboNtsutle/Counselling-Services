-- =====================================================================
--  Ancora — lets the student booking page see which hours are taken.
--  Run once in Supabase > SQL Editor. Safe to run again.
--
--  Students cannot read other people's appointments (and should not), so these two
--  functions hand out ONLY what is needed: the date, hour and psychologist of approved
--  sessions (no student names), and the days psychologists have switched off.
-- =====================================================================

-- Approved sessions: date, hour and which psychologist (nothing about the student).
create or replace function public.approved_slots()
returns table (appointment_date text, appointment_time text, psychologist_id uuid)
language sql stable security definer set search_path = public
as $$
  select a.appointment_date, a.appointment_time, a.psychologist_id
  from public.appointments a
  where a.status = 'Approved' and a.psychologist_id is not null
$$;

-- Days psychologists have switched off (needs supabase/days_off.sql to have been run).
create or replace function public.days_off_all()
returns table (psychologist_id uuid, off_date text)
language sql stable security definer set search_path = public
as $$
  select t.psychologist_id, to_char(t.off_date, 'YYYY-MM-DD')
  from public.psychologist_time_off t
$$;

revoke all on function public.approved_slots() from public;
revoke all on function public.days_off_all()   from public;
grant execute on function public.approved_slots() to authenticated;
grant execute on function public.days_off_all()   to authenticated;
