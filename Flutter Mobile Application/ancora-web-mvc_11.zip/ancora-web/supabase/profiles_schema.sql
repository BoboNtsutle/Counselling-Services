-- =====================================================================
--  Ancora — "profiles" table (standalone: it runs on its own)
--  Run in Supabase > SQL Editor. Safe to run again.
--
--  It does NOT need the appointments table. If that table exists, one extra
--  rule is added (psychologists can read the students who booked with them).
--  Every OLD policy on profiles is removed first, so nothing stale can block saving.
-- =====================================================================

-- 1) THE TABLE ---------------------------------------------------------
create table if not exists public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,  -- same id as the login
  email               text        not null default '',
  display_name        text        not null default '',
  role                text        not null default 'student'
                        check (role in ('student', 'psychologist', 'admin')),
  requested_role      text        not null default 'student'
                        check (requested_role in ('student', 'psychologist', 'admin')),
  role_request_status text        not null default 'none'
                        check (role_request_status in ('none', 'pending', 'approved', 'rejected')),
  student_number      text        not null default '',
  course              text        not null default '',
  phone_number        text        not null default '',
  bio                 text        not null default '',
  created_at          timestamptz not null default now()
);

-- If the table already existed without some columns, add them.
alter table public.profiles add column if not exists email               text        not null default '';
alter table public.profiles add column if not exists display_name        text        not null default '';
alter table public.profiles add column if not exists role                text        not null default 'student';
alter table public.profiles add column if not exists requested_role      text        not null default 'student';
alter table public.profiles add column if not exists role_request_status text        not null default 'none';
alter table public.profiles add column if not exists student_number      text        not null default '';
alter table public.profiles add column if not exists course              text        not null default '';
alter table public.profiles add column if not exists phone_number        text        not null default '';
alter table public.profiles add column if not exists bio                 text        not null default '';
alter table public.profiles add column if not exists created_at          timestamptz not null default now();

create index if not exists profiles_role_idx        on public.profiles (role);
create index if not exists profiles_role_status_idx on public.profiles (role_request_status);
create index if not exists profiles_name_idx        on public.profiles (display_name);

-- 2) HELPER: the signed-in person's role -------------------------------
-- SECURITY DEFINER so the policies below can ask "am I an admin?" without calling themselves forever.
create or replace function public.current_user_role()
returns text
language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

-- 3) PERMISSIONS AND POLICIES ------------------------------------------
alter table public.profiles enable row level security;
grant select, insert, update on public.profiles to authenticated;

-- Remove every old policy on profiles (their names are unknown, and a stale one can block saving).
do $$
declare p record;
begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'profiles'
  loop
    execute format('drop policy %I on public.profiles', p.policyname);
  end loop;
end $$;

-- ---- EVERYONE: read and write their OWN profile ----
create policy "profiles read own" on public.profiles
  for select to authenticated using (id = auth.uid());

create policy "profiles insert own" on public.profiles
  for insert to authenticated with check (id = auth.uid());

create policy "profiles update own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- ---- ADMINS: read and edit every profile ----
create policy "profiles admin read all" on public.profiles
  for select to authenticated using (public.current_user_role() = 'admin');

create policy "profiles admin update" on public.profiles
  for update to authenticated
  using (public.current_user_role() = 'admin') with check (public.current_user_role() = 'admin');

-- ---- STUDENTS and everyone else: see the psychologists (the booking page lists them) ----
create policy "profiles read psychologists" on public.profiles
  for select to authenticated using (role = 'psychologist');

-- ---- PSYCHOLOGISTS: read the students who booked with them (only if appointments exists) ----
do $$
begin
  if to_regclass('public.appointments') is not null then
    execute $p$
      create policy "profiles psychologist read own students" on public.profiles
        for select to authenticated using (
          public.current_user_role() = 'psychologist'
          and exists (
            select 1 from public.appointments a
            where a.student_id = profiles.id and a.psychologist_id = auth.uid()
          )
        )
    $p$;
  end if;
end $$;

-- 4) SAFETY: only an admin may change a role -----------------------------
-- Without this, a student could call the API directly and make themselves an admin.
-- Everyone can still edit their own name, phone, bio, course and student number.
create or replace function public.guard_profile_write()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  -- Only for signed-in app users (the SQL editor has no auth.uid(), so you can still promote the first admin there).
  if auth.uid() is not null and coalesce(public.current_user_role(), 'student') <> 'admin' then
    if tg_op = 'INSERT' then
      new.role := 'student';                                  -- new accounts always start as students
      new.role_request_status :=
        case when new.requested_role = 'student' then 'none' else 'pending' end;
    elsif tg_op = 'UPDATE' then
      new.role := old.role;                                   -- only an admin may change these three
      new.requested_role := old.requested_role;
      new.role_request_status := old.role_request_status;
    end if;
  end if;
  return new;
end $$;

drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard
  before insert or update on public.profiles
  for each row execute function public.guard_profile_write();

-- 5) AFTER RUNNING: make yourself the first admin (use YOUR email), then sign out and in again:
--
--   update public.profiles
--      set role = 'admin', requested_role = 'admin', role_request_status = 'approved'
--    where email = 'you@example.com';
